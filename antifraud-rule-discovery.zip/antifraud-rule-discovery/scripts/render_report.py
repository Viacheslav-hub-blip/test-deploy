#!/usr/bin/env python3
"""Строгий HTML-отчёт из сохранённых фактов. Стандартная библиотека Python.

Использование: python scripts/render_report.py /path/to/research_output
Вход: best_rule.sql и research_config.json. Выход: rule_report.html.
Функции: die, s, esc, table, section, read_examples, check_metrics, scenario_rows, main.
"""
import hashlib
import html
import json
import math
import re
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
CSS = (BASE / "assets" / "report.css").read_text(encoding="utf-8")
SECTIONS = [
    ("data", "Исходные данные", "object"),
    ("feature_inventory", "Карта доступных признаков", "rows"),
    ("feature_coverage", "Охват проверки признаков", "rows"),
    ("text_field_analysis", "Детализация событий по текстовым полям", "rows"),
    ("metrics", "Метрики по точкам принятия решения", "rows"),
    ("client_metrics", "Показатели по клиентам", "rows"),
    ("prevalence_scenarios", "Сценарная частота инцидентов", "rows"),
    ("branches", "Ветки правила и их вклад", "rows"),
    ("feature_contribution", "Вклад признаков", "rows"),
    ("source_robustness", "Отказ признаков и поставщиков", "rows"),
    ("stability", "Стабильность", "rows"),
    ("ablation", "Проверка удаления условий и веток", "rows"),
    ("baseline_comparison", "Сравнение с исходными правилами", "rows"),
    ("search_attempts", "Попытки улучшения", "rows"),
    ("money", "Денежные показатели", "rows"),
    ("checks", "Проверки", "rows"),
]
REQUIRED_CHECKS = {
    "label_integrity", "feature_availability", "no_leakage",
    "sql_equivalence", "test_independence", "examples_verified",
    "alternatives_checked", "resource_budget",
    "feature_inventory", "feature_coverage", "source_robustness",
}


def die(msg):
    """Завершает выполнение: вход — сообщение об ошибке; выход — исключение SystemExit."""
    raise SystemExit("ОШИБКА: " + msg)


def s(value):
    """Форматирует значение: вход — значение отчёта; выход — строка без NaN/Inf."""
    if value is None:
        return "НЕ РАССЧИТАНО"
    if isinstance(value, bool):
        return "да" if value else "нет"
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            die("NaN/Inf в отчёте")
        return format(value, ".10g")
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value)


def esc(value):
    """Экранирует значение: вход — значение отчёта; выход — безопасная HTML-строка."""
    return html.escape(s(value), quote=True)


def table(rows):
    """Строит таблицу: вход — список объектов; выход — HTML с полными именами полей."""
    if not rows:
        return '<p class="missing">НЕТ ДАННЫХ</p>'
    if not isinstance(rows, list) or any(not isinstance(r, dict) for r in rows):
        die("Раздел таблицы должен быть массивом объектов")
    keys = list(dict.fromkeys(k for row in rows for k in row.keys()))
    if not keys:
        return '<p class="missing">НЕТ ДАННЫХ</p>'
    h = "<thead><tr>" + "".join(f"<th>{esc(k)}</th>" for k in keys) + "</tr></thead>"
    b = "<tbody>" + "".join(
        "<tr>" + "".join(f"<td>{esc(row.get(k))}</td>" for k in keys) + "</tr>"
        for row in rows
    ) + "</tbody>"
    return f'<div class="scroll"><table>{h}{b}</table></div>'


def section(title, content):
    """Строит раздел: вход — заголовок и HTML-содержимое; выход — HTML раздела."""
    return f'<section class="section"><h2>{esc(title)}</h2>{content}</section>'


def read_examples(rows, feature_names):
    """Проверяет примеры: вход — список объектов и имена признаков; выход — строки."""
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        die("rule_hit_examples должен быть массивом объектов")
    required = {
        "epk_id", "event_id", "event_time", "target", "example_type", "rule_hit",
        "verified_against_source", "branch_ids", "incident_time", "lead_time_seconds",
    }
    for row in rows:
        if not required.issubset(row):
            die("В rule_hit_examples нет обязательных полей")
        missing_features = set(feature_names) - set(row)
        if missing_features:
            die("В примерах отсутствуют полные колонки: " + ", ".join(sorted(missing_features)))
    # JSON допускает числа и bool; приводим скаляры к прежнему формату CSV.
    rows = [{key: "" if value is None else str(value) for key, value in row.items()}
            for row in rows]
    ids = set()
    for r in rows:
        if not r["epk_id"].strip() or not r["event_id"].strip():
            die("Пустой epk_id/event_id")
        if (r["epk_id"], r["event_id"]) in ids:
            die("Повтор пары epk_id/event_id в примерах")
        ids.add((r["epk_id"], r["event_id"]))
        if r["rule_hit"].strip().lower() not in ("1", "true"):
            die("Пример не является срабатыванием правила")
        if r["verified_against_source"].strip().lower() not in ("1", "true"):
            die("Неподтверждённый пример срабатывания")
        allowed = {"incident_tp": "1", "target0_hit": "0", "early_alert_before_incident": "0"}
        kind = r["example_type"].strip()
        if kind not in allowed or r["target"].strip() != allowed[kind]:
            die("Тип примера не соответствует исходной метке target")
        if kind == "incident_tp":
            if not r["incident_time"].strip():
                die("У incident_tp отсутствует время инцидента")
            lead = r["lead_time_seconds"].strip()
            if lead and (not lead.replace(".", "", 1).isdigit() or float(lead) != 0):
                die("Для incident_tp опережение должно быть нулевым")
        if kind == "early_alert_before_incident":
            if not r["incident_time"].strip() or not r["lead_time_seconds"].strip():
                die("Для раннего предупреждения нужны время инцидента и опережение")
            try:
                lead = float(r["lead_time_seconds"])
            except ValueError:
                die("Некорректное опережение раннего предупреждения")
            if not 0 < lead < float("inf"):
                die("Опережение раннего предупреждения должно быть положительным")
    return rows


def check_metrics(rows):
    """Проверяет метрики: вход — список счётчиков; выход — строки с TPR/FPR/Precision."""
    if not isinstance(rows, list):
        die("metrics должен быть массивом")
    for row in rows:
        if not isinstance(row, dict):
            die("Запись metrics должна быть объектом")
        if all(k in row for k in ("tp", "fp", "fn", "tn")):
            counts = [row[k] for k in ("tp", "fp", "fn", "tn")]
            if any(not isinstance(k, int) or isinstance(k, bool) or k < 0 for k in counts):
                die("TP/FP/FN/TN должны быть целыми неотрицательными")
            tp, fp, fn, tn = counts
            expected = {
                "tpr": tp/(tp+fn) if tp+fn else None,
                "fpr": fp/(fp+tn) if fp+tn else None,
                "precision_sample": tp/(tp+fp) if tp+fp else None,
            }
            for k, v in expected.items():
                if k in row and row[k] is not None and (v is None or not isinstance(row[k], (int, float)) or not math.isclose(row[k], v, abs_tol=1e-8, rel_tol=1e-6)):
                    die(f"Арифметическая ошибка: {row.get('split', '')}/{k}")
                row.setdefault(k, v)
    return rows


def scenario_rows(data, metrics):
    """Считает сценарии: вход — настройки и метрики Test; выход — список оценок."""
    supplied = data.get("prevalence_scenarios", [])
    if not supplied:
        return []
    tests = [r for r in metrics if str(r.get("split", "")).lower() == "test" and str(r.get("unit", "event")).lower() == "event"]
    if not tests and data.get("research", {}).get("status") == "partial":
        return []  # Нет независимых показателей: сценарные цифры не вычисляются.
    if len(tests) != 1:
        die("Для расчёта сценариев нужен ровно один итоговый event-level Test")
    tpr, fpr = tests[0].get("tpr"), tests[0].get("fpr")
    if tpr is None or fpr is None:
        die("Нет TPR/FPR для расчёта сценариев")
    rows = []
    for item in supplied:
        if not isinstance(item, dict) or "prevalence_percent" not in item:
            die("Сценарий требует prevalence_percent (в процентах)")
        pct = item["prevalence_percent"]
        if not isinstance(pct, (int, float)) or not 0 <= pct <= 100:
            die("Некорректный prevalence_percent")
        p = pct/100.0
        alert = p*tpr + (1-p)*fpr
        rows.append({
            "prevalence_percent_сценарий": pct,
            "precision_expected_условно": p*tpr/alert if alert else None,
            "alert_rate_expected": alert,
            "tp_per_1m_expected": 1_000_000*p*tpr,
            "fp_per_1m_expected": 1_000_000*(1-p)*fpr,
            "assumption": "TPR/FPR переносимы; единица и горизонт совпадают",
        })
    return rows


def main(folder):
    """Собирает отчёт: вход — путь к результатам; выход — HTML-файл, возврат None."""
    folder = Path(folder).expanduser().resolve()
    sql_path = folder / "best_rule.sql"
    data_path = folder / "research_config.json"
    if not sql_path.exists() or not data_path.exists():
        die("Нужны best_rule.sql и research_config.json")
    sql = sql_path.read_text(encoding="utf-8")
    if not sql.strip() or re.search(r"\.\.\.|\bTODO\b|другие ветки|<feature|<condition", sql, re.I):
        die("SQL пустой или содержит заглушки/сокращения")
    data = json.loads(data_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("research"), dict):
        die("Не задан объект research")
    research = data["research"]
    status = research.get("status")
    if status not in ("complete", "partial"):
        die("research.status должен быть complete/partial")
    feature_names = data.get("feature_names_exact", [])
    if not isinstance(feature_names, list) or any(not isinstance(x, str) or not x for x in feature_names):
        die("feature_names_exact должен быть списком полных имён")
    if len(set(feature_names)) != len(feature_names):
        die("Повтор имён признаков")
    examples = read_examples(data.get("rule_hit_examples", []), feature_names)
    metrics = check_metrics(data.get("metrics", []))
    # Снимок финального Test сохраняется при оценке, до сборки HTML.
    # Хеш проверяет неизменность SQL, но не доказывает независимость Test.
    verified_test = data.get("test_metrics")
    if verified_test is not None:
        if not isinstance(verified_test, dict):
            die("test_metrics в research_config.json должен быть объектом")
        expected_sha = hashlib.sha256(sql_path.read_bytes()).hexdigest()
        if verified_test.get("best_rule_sha256") != expected_sha:
            die("SHA-256 best_rule.sql не совпадает с test_metrics в research_config.json")
        tests = [r for r in metrics if str(r.get("split", "")).lower() == "test" and str(r.get("unit", "event")).lower() == "event"]
        if len(tests) != 1:
            die("Для проверки test_metrics в research_config.json нужен один итоговый event-level Test")
        for k in ("tp", "fp", "fn", "tn"):
            v = verified_test.get(k)
            if not isinstance(v, int) or isinstance(v, bool) or v < 0 or tests[0].get(k) != v:
                die("Несоответствие финального Test по полю " + k)
    if status == "complete":
        if not feature_names:
            die("complete: нужен список полных имён признаков из финального SQL")
        if any(name not in sql for name in feature_names):
            die("complete: не все feature_names_exact встречаются в финальном SQL")
        inventory = data.get("feature_inventory", [])
        coverage = data.get("feature_coverage", [])
        contribution = data.get("feature_contribution", [])
        outages = data.get("source_robustness", [])
        if not inventory or not isinstance(inventory, list):
            die("complete: отсутствует карта входных признаков")
        names = [r.get("name_exact") for r in inventory if isinstance(r, dict)]
        if len(names) != len(inventory) or any(not x for x in names) or len(set(names)) != len(names):
            die("complete: неверная карта признаков или повтор имён")
        declared_count = data.get("data", {}).get("feature_count")
        if declared_count is not None and declared_count != len(inventory):
            die("complete: число признаков не совпадает с картой")
        if not isinstance(coverage, list) or set(r.get("name_exact") for r in coverage if isinstance(r, dict)) != set(names):
            die("complete: исследованы не все входные признаки")
        if not isinstance(contribution, list) or not set(feature_names).issubset({r.get("name_exact") for r in contribution if isinstance(r, dict)}):
            die("complete: не измерен вклад всех признаков финального SQL")
        if not isinstance(outages, list):
            die("complete: отсутствует проверка отказов")
        checked_features = {r.get("source_or_feature_exact") for r in outages if isinstance(r, dict) and r.get("failure_type") == "feature"}
        if not set(feature_names).issubset(checked_features):
            die("complete: не проверен отказ каждого используемого признака")
        providers = {r.get("provider") for r in inventory if isinstance(r, dict) and r.get("name_exact") in feature_names and r.get("provider") not in (None, "", "unknown")}
        checked_providers = {r.get("source_or_feature_exact") for r in outages if isinstance(r, dict) and r.get("failure_type") == "provider"}
        if not providers.issubset(checked_providers):
            die("complete: не проверен отказ известного поставщика")
        if verified_test is None:
            die("complete: требуется test_metrics в research_config.json с SHA-256 и счётчиками")
        tests = [r for r in metrics if str(r.get("split", "")).lower() == "test" and str(r.get("unit", "event")).lower() == "event"]
        # При отсутствии срабатываний реальные примеры физически невозможны.
        if tests[0]["tp"] + tests[0]["fp"] > 0 and not examples:
            die("complete: есть Test-срабатывания, но нет ни одного реального примера")
        checks_rows = data.get("checks", [])
        if not isinstance(checks_rows, list):
            die("checks должен быть массивом объектов")
        checks = {r.get("check_id"): r for r in checks_rows if isinstance(r, dict)}
        missing = sorted(k for k in REQUIRED_CHECKS if checks.get(k, {}).get("status") != "passed"
                         or not str(checks.get(k, {}).get("evidence", "")).strip())
        if missing:
            die("complete: проверки без статуса passed или свидетельства: " + ", ".join(missing))
    scenarios = scenario_rows(data, metrics)
    sections = [section("Постановка исследования", table([research]))]
    sections.append(section("Полное финальное SQL-правило", '<div class="scroll"><pre><code id="full-sql">' + html.escape(sql, quote=False) + "</code></pre></div>"))
    for key, title, kind in SECTIONS:
        if key == "text_field_analysis" and not data.get(key):
            continue
        value = metrics if key == "metrics" else scenarios if key == "prevalence_scenarios" else data.get(key, [] if kind == "rows" else {})
        rows = [value] if kind == "object" and isinstance(value, dict) else value
        sections.append(section(title, table(rows)))
    sections.append(section("Примеры реальных срабатываний: epk_id / event_id", table(examples)))
    sections.append(section("Примеры пропущенных инцидентов (FN)", table(data.get("missed_incident_examples", []))))
    limitations = data.get("limitations", [])
    if limitations and not isinstance(limitations, list):
        die("limitations должен быть массивом")
    sections.append(section("Ограничения / НЕ РАССЧИТАНО", table([{"limitation": x} for x in limitations])))
    status_text = "ПОЛНЫЙ ПРОТОКОЛ" if status == "complete" else "НЕ ПОЛНОСТЬЮ ПРОВЕРЕНО"
    page = f'''<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Антифрод: отчёт {esc(research.get("run_id"))}</title><style>{CSS}</style></head><body>
<header><h1>Антифрод — протокол исследования</h1><p class="meta">{esc(research.get("run_id"))} · {esc(research.get("source_version"))} · {esc(research.get("period"))}</p><span class="pill">{esc(status_text)}</span></header>
{''.join(sections)}<p class="foot">SQL загружен из best_rule.sql без изменения. Метрики и примеры — из файлов исследования. Сценарные значения не являются измеренным production-результатом.</p>
</body></html>'''
    out = folder / "rule_report.html"
    tmp = folder / "rule_report.html.tmp"
    tmp.write_text(page, encoding="utf-8")
    tmp.replace(out)
    # Контроль точного SQL внутри HTML после HTML-декодирования.
    fragment = re.search(r'<code id="full-sql">(.*?)</code>', out.read_text(encoding="utf-8"), flags=re.S)
    if not fragment or html.unescape(fragment.group(1)) != sql:
        die("SQL внутри HTML не совпадает с best_rule.sql")
    print(f"OK: {out} | SQL exact | examples={len(examples)} | status={status}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        die("python scripts/render_report.py /path/to/research_output")
    main(sys.argv[1])
