#!/usr/bin/env python3
"""Проверка HTML-генератора на синтетических данных.

Функции: run — создаёт временные входные данные и проверяет результат.
"""
import hashlib
import json
import re
import tempfile
from pathlib import Path
from render_report import main, REQUIRED_CHECKS


def run():
    """Проверяет генератор: входных аргументов нет; выход — проверки, возврат None."""
    with tempfile.TemporaryDirectory(prefix="antifraud_report_test_") as tmp:
        p = Path(tmp)
        sql = "CASE WHEN (\n    \"full_original_feature_name\" >= 7\n    AND \"second_original_feature_name\" = 1\n) THEN 1 ELSE 0 END AS risk_flag\n"
        (p / "best_rule.sql").write_text(sql, encoding="utf-8")
        sql_sha = hashlib.sha256((p / "best_rule.sql").read_bytes()).hexdigest()
        data = {
            "research": {"run_id": "SYNTHETIC_TEST_ONLY", "status": "complete", "source_version": "fake",
                         "period": "synthetic", "decision_unit": "event", "evaluation_mode": "target_on_current_event"},
            "data": {"rows": 1000, "decision_points": 900, "registered_incidents": 10, "feature_count": 2},
            "feature_names_exact": ["full_original_feature_name", "second_original_feature_name"],
            "feature_inventory": [{"name_exact": "full_original_feature_name", "source": "synthetic_a", "provider": "unknown"}, {"name_exact": "second_original_feature_name", "source": "synthetic_b", "provider": "unknown"}],
            "feature_coverage": [{"name_exact": "full_original_feature_name", "assessment_status": "tested"}, {"name_exact": "second_original_feature_name", "assessment_status": "tested"}],
            "metrics": [{"split": "Test", "unit": "event", "tp": 2, "fp": 1, "fn": 3, "tn": 994, "tpr": 0.4, "fpr": 1 / 995}],
            "client_metrics": [{"victims_warned": 2, "clients_without_registered_incident_alerted": 1}],
            "prevalence_scenarios": [{"prevalence_percent": 0.0034}],
            "branches": [{"branch_id": 1, "full_expression": sql, "additional_tp": 2, "additional_fp": 1}],
            "feature_contribution": [{"name_exact": "full_original_feature_name", "delta_tp_unavailable": -1},
                                     {"name_exact": "second_original_feature_name", "delta_tp_unavailable": -2}],
            "source_robustness": [{"failure_type": "feature", "source_or_feature_exact": "full_original_feature_name", "delta_TP": -1},
                                  {"failure_type": "feature", "source_or_feature_exact": "second_original_feature_name", "delta_TP": -2}],
            "stability": [], "ablation": [], "baseline_comparison": [], "search_attempts": [],
            "money": [{"metric": "covered_loss_amount", "value": None, "reason": "no confirmed amount"}],
            "checks": [{"check_id": k, "status": "passed", "evidence": "synthetic self-test"} for k in REQUIRED_CHECKS],
            "limitations": ["Synthetic test only"],
        }
        data["test_metrics"] = {"best_rule_sha256": sql_sha, "tp": 2, "fp": 1, "fn": 3, "tn": 994}
        data["rule_hit_examples"] = [{
            "epk_id": "synthetic_client_A", "event_id": "synthetic_event_B", "event_time": "2026-01-01T10:00:00",
            "target": 1, "example_type": "incident_tp", "rule_hit": True, "verified_against_source": True,
            "branch_ids": "1", "incident_time": "2026-01-01T10:00:00", "lead_time_seconds": 0,
            "full_original_feature_name": 7, "second_original_feature_name": 1,
        }]
        data["missed_incident_examples"] = [{"epk_id": "synthetic_missed_client", "event_id": "synthetic_missed_event", "target": 1, "rule_hit": 0}]
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        main(p)
        # Полный отчёт требует снимок Test и реальные примеры при срабатываниях.
        for field, message in (("test_metrics", "требуется test_metrics"),
                               ("rule_hit_examples", "нет ни одного реального примера")):
            saved_value = data.pop(field)
            (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            try:
                main(p)
            except SystemExit as exc:
                assert message in str(exc)
            else:
                raise AssertionError("Missing complete report data was not detected: " + field)
            data[field] = saved_value
        # Несовместимые target и тип примера должны блокировать отчёт.
        data["rule_hit_examples"][0]["example_type"] = "target0_hit"
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        try:
            main(p)
        except SystemExit as exc:
            assert "метке target" in str(exc)
        else:
            raise AssertionError("Example label shift was not detected")
        data["rule_hit_examples"][0]["example_type"] = "incident_tp"
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        main(p)
        page = (p / "rule_report.html").read_text(encoding="utf-8")
        assert "synthetic_client_A" in page
        assert "synthetic_event_B" in page
        assert "synthetic_missed_client" in page
        assert "full_original_feature_name" in page
        assert "Отказ признаков и поставщиков" in page
        assert "Карта доступных признаков" in page
        # Раздел текстовых подтипов появляется только при наличии результатов.
        assert "Детализация событий по текстовым полям" not in page
        data["text_field_analysis"] = [{"event_type": "FS_REQUEST", "source_field_exact": "event_description", "subtype": "synthetic_subtype", "tp": 1, "fp": 0}]
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        main(p)
        text_page = (p / "rule_report.html").read_text(encoding="utf-8")
        assert "Детализация событий по текстовым полям" in text_page
        assert "event_description" in text_page
        assert "synthetic_subtype" in text_page
        assert '0.0034' in page
        assert '<code id="full-sql">' in page
        assert '1000' in page
        # Вычисленные из 2/5 и 1/995 значения не должны быть придуманы вручную.
        assert re.search(r"0\.4", page)
        assert sql in __import__("html").unescape(__import__("re").search(
            r'<code id="full-sql">(.*?)</code>', page, flags=re.S).group(1))
        # Пропущенный признак из входной карты не должен проходить complete.
        broken_data = json.loads((p / "research_config.json").read_text(encoding="utf-8"))
        broken_data["feature_coverage"] = broken_data["feature_coverage"][:1]
        (p / "research_config.json").write_text(json.dumps(broken_data, ensure_ascii=False), encoding="utf-8")
        try:
            main(p)
        except SystemExit as exc:
            assert "все входные признаки" in str(exc)
        else:
            raise AssertionError("Incomplete feature coverage was not detected")
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        # Снимок Test относится к точным байтам SQL: замена SQL должна блокировать сборку.
        (p / "best_rule.sql").write_text(sql + "\n", encoding="utf-8")
        try:
            main(p)
        except SystemExit as exc:
            assert "SHA-256" in str(exc)
        else:
            raise AssertionError("SQL modification was not detected")
        # Несогласованные счётчики тоже должны блокировать отчёт.
        (p / "best_rule.sql").write_text(sql, encoding="utf-8")
        data["test_metrics"]["fp"] = 999
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        try:
            main(p)
        except SystemExit as exc:
            assert "Test" in str(exc)
        else:
            raise AssertionError("Test count change was not detected")
        # Частично выполненный запуск допускается без Test, даже если сценарии
        # были оставлены в данных. Сценарные числа без Test не вычисляются.
        data["research"]["status"] = "partial"
        data["metrics"] = []
        data.pop("test_metrics")
        (p / "research_config.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        main(p)
        partial_page = (p / "rule_report.html").read_text(encoding="utf-8")
        assert "НЕ ПОЛНОСТЬЮ ПРОВЕРЕНО" in partial_page
        assert {item.name for item in p.iterdir()} == {"best_rule.sql", "research_config.json", "rule_report.html"}
        print("PASS: HTML, exact SQL, IDs, scenario, SQL hash, Test counts, partial without Test")


if __name__ == "__main__":
    run()
