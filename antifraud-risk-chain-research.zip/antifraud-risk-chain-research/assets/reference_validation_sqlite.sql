-- SQLite. Воспроизведение исходной методики исследования (не промышленная выборка).
-- Метка fraud_time задаёт границу наблюдения только при оценке качества.
-- G1 из исследования считает ATM_CASH только внутри 48-часового окна выгрузки.
-- G2/G7/G8 использовали предысторию в полном массиве (до 24 часов до текущего события),
-- поэтому вычисляются от основного антифрод-представления, а НЕ от обрезанной таблицы.
-- Иначе теряются граничные цепочки, и показатели не совпадают с исследованием.
DROP VIEW IF EXISTS temp.antifraud_eval_event_flags;
DROP TABLE IF EXISTS temp.eval_events;
CREATE TEMP TABLE eval_events AS
WITH bounds AS (
    SELECT epk_id,
           COALESCE(MIN(CASE WHEN NULLIF(TRIM(fraud_time), '') IS NOT NULL
                             THEN fraud_time END),
                    MAX(event_time)) AS cutoff_time
    FROM events GROUP BY epk_id
)
SELECT e.rowid AS original_event_row_id, e.*
FROM events e JOIN bounds b ON e.epk_id=b.epk_id
WHERE e.event_time BETWEEN datetime(b.cutoff_time, '-48 hours') AND b.cutoff_time;
CREATE INDEX idx_eval_client_subtype_time ON eval_events(epk_id,sub_type,event_time);

CREATE TEMP VIEW antifraud_eval_event_flags AS
WITH scoped AS (
    SELECT f.event_row_id, f.epk_id, f.event_time, f.event_type, f.sub_type,
           f.dsl_score, f.amount_rub,
           CASE WHEN (
               SELECT COUNT(*) FROM eval_events AS a
               WHERE a.epk_id = f.epk_id AND a.sub_type = 'ATM_CASH'
                 AND a.event_time BETWEEN datetime(f.event_time, '-48 hours') AND f.event_time
           ) >= 2 THEN 1 ELSE 0 END AS g1_atm_cash_48h,
           f.g2_epos_pos_payment, f.g3_epos_score, f.g4_c2b_score,
           f.g5_score_amount, f.g6_rurpayjursb, f.g7_vk_without_otp, f.g8_account_epos
    FROM antifraud_event_flags AS f
    JOIN eval_events AS e ON e.original_event_row_id = f.event_row_id
)
SELECT scoped.*,
       CASE WHEN g1_atm_cash_48h=1 OR g2_epos_pos_payment=1 OR
                 g3_epos_score=1 OR g4_c2b_score=1 OR
                 g5_score_amount=1 OR g6_rurpayjursb=1 OR
                 g7_vk_without_otp=1 OR g8_account_epos=1
            THEN 1 ELSE 0 END AS antifraud_flag
FROM scoped;

-- РЕЗУЛЬТАТ проверки: одна строка на клиента в 48-часовом сопоставимом окне.
WITH truth AS (
 SELECT epk_id, MAX(CASE WHEN NULLIF(TRIM(fraud_time),'') IS NOT NULL
                         THEN 1 ELSE 0 END) AS actual_fraud,
        MIN(CASE WHEN NULLIF(TRIM(fraud_time),'') IS NOT NULL
                 THEN fraud_time END) AS first_fraud_time
 FROM events GROUP BY epk_id
),
pred AS (
 SELECT t.epk_id,t.actual_fraud,t.first_fraud_time,
        COALESCE(MAX(f.antifraud_flag),0) AS predicted_fraud,
        MIN(CASE WHEN f.antifraud_flag=1 THEN f.event_time END) AS first_alert_time
 FROM truth t LEFT JOIN antifraud_eval_event_flags f ON f.epk_id=t.epk_id
 GROUP BY t.epk_id,t.actual_fraud,t.first_fraud_time
),
m AS (
 SELECT SUM(CASE WHEN actual_fraud=1 AND predicted_fraud=1 THEN 1 ELSE 0 END) AS tp,
        SUM(CASE WHEN actual_fraud=0 AND predicted_fraud=1 THEN 1 ELSE 0 END) AS fp,
        SUM(CASE WHEN actual_fraud=1 AND predicted_fraud=0 THEN 1 ELSE 0 END) AS fn,
        SUM(CASE WHEN actual_fraud=0 AND predicted_fraud=0 THEN 1 ELSE 0 END) AS tn,
        SUM(CASE WHEN actual_fraud=1 AND first_alert_time<=datetime(first_fraud_time,'-1 minute')
                  THEN 1 ELSE 0 END) AS early_tp
 FROM pred
)
SELECT *,ROUND(100.0*tp/NULLIF(tp+fn,0),2) AS recall_pct,
         ROUND(100.0*tp/NULLIF(tp+fp,0),2) AS precision_pct,
         ROUND(100.0*early_tp/NULLIF(tp+fn,0),2) AS early_recall_pct
FROM m;
