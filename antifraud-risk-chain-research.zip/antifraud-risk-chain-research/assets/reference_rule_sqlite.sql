-- SQLite 3.25+; входная таблица events создана из исходного Excel.
-- Обязательные колонки: epk_id, event_time, event_type, sub_type,
-- cards_dsl_model_risk_score, inrubles.
-- event_time хранится в ISO 8601: YYYY-MM-DD HH:MM:SS.
-- Входные данные не фильтруются по типам событий.
-- Метки fraud_time/last_resol/source_fraud НИКОГДА не используются при вычислении флагов.
-- В обычной SQLite-таблице rowid идентифицирует отдельную строку, в том числе дубликаты.
-- При переносе на другую СУБД замените rowid на технический event_id/row_id.

CREATE INDEX IF NOT EXISTS idx_antifraud_client_time
    ON events (epk_id, event_time);
CREATE INDEX IF NOT EXISTS idx_antifraud_client_subtype_time
    ON events (epk_id, sub_type, event_time);

DROP VIEW IF EXISTS antifraud_event_flags;
CREATE VIEW antifraud_event_flags AS
WITH normalized AS (
    SELECT
        e.rowid AS event_row_id,
        e.epk_id,
        e.event_time,
        e.event_type,
        e.sub_type,
        CAST(NULLIF(TRIM(CAST(e.cards_dsl_model_risk_score AS TEXT)), '') AS REAL) AS dsl_score,
        CAST(REPLACE(NULLIF(TRIM(CAST(e.inrubles AS TEXT)), ''), ',', '.') AS REAL) AS amount_rub
    FROM events AS e
),
flags AS (
    SELECT
        e.*,

        -- G1: не менее двух ATM_CASH за последние 48 часов, включая текущее событие.
        CASE WHEN (
            SELECT COUNT(*)
            FROM normalized AS a
            WHERE a.epk_id = e.epk_id
              AND a.sub_type = 'ATM_CASH'
              AND a.event_time >= datetime(e.event_time, '-48 hours')
              AND a.event_time <= e.event_time
        ) >= 2 THEN 1 ELSE 0 END AS g1_atm_cash_48h,

        -- G2: EPOS_PURCHASE(A) -> POS_PURCHASE(B) -> текущая PAYMENT/WITHDRAW,
        -- t(A) < t(B) < t(current), t(current)-t(A) <= 24 часов.
        CASE WHEN e.event_type IN ('PAYMENT', 'WITHDRAW')
                 AND e.dsl_score >= 400
                 AND EXISTS (
                     SELECT 1
                     FROM normalized AS b
                     WHERE b.epk_id = e.epk_id
                       AND b.sub_type = 'POS_PURCHASE'
                       AND b.event_time < e.event_time
                       AND b.event_time >= datetime(e.event_time, '-24 hours')
                       AND EXISTS (
                           SELECT 1
                           FROM normalized AS a
                           WHERE a.epk_id = e.epk_id
                             AND a.sub_type = 'EPOS_PURCHASE'
                             AND a.event_time < b.event_time
                             AND a.event_time >= datetime(e.event_time, '-24 hours')
                       )
                 ) THEN 1 ELSE 0 END AS g2_epos_pos_payment,

        -- G3: ePOS с высоким скором.
        CASE WHEN e.sub_type = 'EPOS_PURCHASE' AND e.dsl_score >= 450
             THEN 1 ELSE 0 END AS g3_epos_score,

        -- G4: C2B-подписка со скором >= 250.
        CASE WHEN e.sub_type = 'C2B_SUBSCRIBE' AND e.dsl_score >= 250
             THEN 1 ELSE 0 END AS g4_c2b_score,

        -- G5: высокий скор и сумма в рублях.
        CASE WHEN e.dsl_score >= 800 AND e.amount_rub >= 500
             THEN 1 ELSE 0 END AS g5_score_amount,

        -- G6: перевод юрлицу со скором >= 450.
        CASE WHEN e.sub_type = 'RURPAYJURSB' AND e.dsl_score >= 450
             THEN 1 ELSE 0 END AS g6_rurpayjursb,

        -- G7: VK_CHECK(A) -> WITHOUT_OTP(B) -> текущая PAYMENT/WITHDRAW.
        CASE WHEN e.event_type IN ('PAYMENT', 'WITHDRAW')
                 AND e.dsl_score >= 400
                 AND EXISTS (
                     SELECT 1
                     FROM normalized AS b
                     WHERE b.epk_id = e.epk_id
                       AND b.sub_type = 'WITHOUT_OTP'
                       AND b.event_time < e.event_time
                       AND b.event_time >= datetime(e.event_time, '-24 hours')
                       AND EXISTS (
                           SELECT 1
                           FROM normalized AS a
                           WHERE a.epk_id = e.epk_id
                             AND a.sub_type = 'VK_CHECK'
                             AND a.event_time < b.event_time
                             AND a.event_time >= datetime(e.event_time, '-24 hours')
                       )
                 ) THEN 1 ELSE 0 END AS g7_vk_without_otp,

        -- G8: ACCOUNT(A) -> текущая EPOS_PURCHASE за 24 часа, скор текущей >= 300.
        CASE WHEN e.sub_type = 'EPOS_PURCHASE'
                 AND e.dsl_score >= 300
                 AND EXISTS (
                     SELECT 1
                     FROM normalized AS a
                     WHERE a.epk_id = e.epk_id
                       AND a.sub_type = 'ACCOUNT'
                       AND a.event_time < e.event_time
                       AND a.event_time >= datetime(e.event_time, '-24 hours')
                 ) THEN 1 ELSE 0 END AS g8_account_epos
    FROM normalized AS e
)
SELECT
    f.*,
    CASE WHEN (
        g1_atm_cash_48h = 1 OR g2_epos_pos_payment = 1 OR
        g3_epos_score = 1 OR g4_c2b_score = 1 OR
        g5_score_amount = 1 OR g6_rurpayjursb = 1 OR
        g7_vk_without_otp = 1 OR g8_account_epos = 1
    ) THEN 1 ELSE 0 END AS antifraud_flag,
    RTRIM(
        (CASE WHEN g1_atm_cash_48h = 1 THEN 'G1_ATM_CASH_48H,' ELSE '' END) ||
        (CASE WHEN g2_epos_pos_payment = 1 THEN 'G2_EPOS_POS_PAYMENT,' ELSE '' END) ||
        (CASE WHEN g3_epos_score = 1 THEN 'G3_EPOS_SCORE,' ELSE '' END) ||
        (CASE WHEN g4_c2b_score = 1 THEN 'G4_C2B_SCORE,' ELSE '' END) ||
        (CASE WHEN g5_score_amount = 1 THEN 'G5_SCORE_AMOUNT,' ELSE '' END) ||
        (CASE WHEN g6_rurpayjursb = 1 THEN 'G6_RURPAYJURSB,' ELSE '' END) ||
        (CASE WHEN g7_vk_without_otp = 1 THEN 'G7_VK_WITHOUT_OTP,' ELSE '' END) ||
        (CASE WHEN g8_account_epos = 1 THEN 'G8_ACCOUNT_EPOS,' ELSE '' END),
        ','
    ) AS triggered_groups
FROM flags AS f;

-- Просмотр сработок на УРОВНЕ СОБЫТИЙ (показать все события — убрать WHERE):
SELECT event_row_id, epk_id, event_time, event_type, sub_type,
       dsl_score, amount_rub, antifraud_flag, triggered_groups
FROM antifraud_event_flags
WHERE antifraud_flag = 1
ORDER BY epk_id, event_time, event_row_id;

-- Для оценки клиента как 0/1 используйте ОТДЕЛЬНЫЙ запрос:
-- SELECT epk_id, MAX(antifraud_flag) AS client_flag
-- FROM antifraud_event_flags GROUP BY epk_id;
