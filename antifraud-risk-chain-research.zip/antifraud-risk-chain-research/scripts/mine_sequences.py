#!/usr/bin/env python3
"""Discover gapped ordered pairs/triples with 24h global span and client-level control."""
import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
import csv
from datetime import datetime, timedelta
import json
from pathlib import Path
import sqlite3


def read_histories(db_path, window_hours=48):
    connection = sqlite3.connect(db_path)
    cols = {r[1] for r in connection.execute('PRAGMA table_info(events)')}
    if 'fraud_time' not in cols:
        raise ValueError('Offline supervised pattern mining needs fraud_time')
    histories = defaultdict(list)
    for rid, client, time, subtype, fraud in connection.execute(
            'SELECT rowid,epk_id,event_time,sub_type,fraud_time FROM events'):
        if not client or not time:
            raise ValueError('Missing epk_id or event_time')
        histories[client].append((datetime.fromisoformat(time.replace('T', ' ')), rid,
                                  subtype or '(EMPTY)',
                                  datetime.fromisoformat(fraud.replace('T', ' ')) if fraud and fraud.strip() else None))
    connection.close()
    result = {}
    for client, rows in histories.items():
        rows.sort(key=lambda z: (z[0], z[1]))
        fraud_times = [r[3] for r in rows if r[3] is not None]
        anchor = min(fraud_times) if fraud_times else rows[-1][0]
        result[client] = (bool(fraud_times), [(r[0], r[2]) for r in rows
                                               if anchor - timedelta(hours=window_hours) <= r[0] <= (anchor - timedelta(minutes=1) if fraud_times else anchor)])
    return result


def extract_pairs(seq, window):
    pairs = set()
    examples = {}
    for j, (tj, sj) in enumerate(seq):
        for i in range(j - 1, -1, -1):
            ti, si = seq[i]
            if tj - ti > window:
                break
            if ti < tj:
                key = (si, sj)
                pairs.add(key)
                examples.setdefault(key, (str(ti), str(tj), j - i - 1))
    return pairs, examples


def extract_triples(seq, window, max_patterns):
    triples = set()
    examples = {}
    for c in range(2, len(seq)):
        tc, sc = seq[c]
        for b in range(c - 1, 0, -1):
            tb, sb = seq[b]
            if tc - tb > window:
                break
            if not tb < tc:
                continue
            for a in range(b - 1, -1, -1):
                ta, sa = seq[a]
                if tc - ta > window:
                    break
                if ta >= tb:
                    continue
                key = (sa, sb, sc)
                triples.add(key)
                examples.setdefault(key, (str(ta), str(tb), str(tc), c - a - 2))
        if len(triples) > max_patterns:
            raise ValueError('Triplet explosion. Raise support or shorten time window.')
    return triples, examples


def matched_control_triples(seq, candidate_set, window):
    by_last_middle = defaultdict(set)
    for a, b, c in candidate_set:
        by_last_middle[(c, b)].add(a)
    times = defaultdict(list)
    for t, subtype in seq:
        times[subtype].append(t)
    result = set()
    for c, (tc, sc) in enumerate(seq):
        for b in range(c - 1, 0, -1):
            tb, sb = seq[b]
            if tc - tb > window:
                break
            if not tb < tc:
                continue
            choices = by_last_middle.get((sc, sb), ())
            for first in choices:
                vals = times[first]
                ix = bisect_left(vals, tc - window)
                if ix < len(vals) and vals[ix] < tb:
                    result.add((first, sb, sc))
    return result


def optional_pvals(rows, n_positive, n_negative, conditional=False):
    try:
        from scipy.stats import fisher_exact
        from statsmodels.stats.multitest import multipletests
    except ImportError:
        for row in rows:
            row['p_fisher'] = ''
            row['q_bh_conditional' if conditional else 'q_bh'] = ''
        return
    pv = [fisher_exact([[row['fraud'], n_positive - row['fraud']],
                        [row['legit'], n_negative - row['legit']]], alternative='greater')[1]
          for row in rows]
    qs = multipletests(pv, method='fdr_bh')[1] if pv else []
    for row, p, q in zip(rows, pv, qs):
        row['p_fisher'] = p
        row['q_bh_conditional' if conditional else 'q_bh'] = float(q)


def write_csv(path, rows, fieldnames):
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def mine(db, out, window_hours=24, history_hours=48, min_positive_support=5,
         max_patterns=300000):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    histories = read_histories(db, history_hours)
    n_pos = sum(y for y, _ in histories.values())
    n_neg = len(histories) - n_pos
    if not n_pos or not n_neg:
        raise ValueError('Both fraud and legitimate clients are needed for comparisons')
    window = timedelta(hours=window_hours)
    pair_pos, pair_neg, triple_pos = Counter(), Counter(), Counter()
    pair_examples, triple_examples = {}, {}
    for client, (fraud, seq) in histories.items():
        pp, pe = extract_pairs(seq, window)
        (pair_pos if fraud else pair_neg).update(pp)
        if fraud:
            for key, value in pe.items():
                pair_examples.setdefault(key, (client, *value))
            tt, te = extract_triples(seq, window, max_patterns)
            triple_pos.update(tt)
            for key, value in te.items():
                triple_examples.setdefault(key, (client, *value))
            if len(triple_pos) > max_patterns:
                raise ValueError('Global triplet explosion. Increase minimum support via a prefix miner.')
    candidates = {q for q, count in triple_pos.items() if count >= min_positive_support}
    triple_neg = Counter()
    for client, (fraud, seq) in histories.items():
        if not fraud:
            triple_neg.update(matched_control_triples(seq, candidates, window))
    def fmt(key, pos, neg, example):
        f, n = pos, neg
        prevalence = n_pos / (n_pos + n_neg)
        precision = f / (f + n) if f + n else None
        return {'pattern': ' -> '.join(key), 'length': len(key), 'fraud': f, 'legit': n,
                'precision_in_sample': precision,
                'relative_frequency': (f / n_pos) / (n / n_neg) if n else '',
                'lift_in_sample': precision / prevalence if precision is not None else None,
                'example_client': example[0] if example else '',
                'example_times': ' | '.join(example[1:-1]) if example else '',
                'intermediate_events': example[-1] if example else ''}
    pairs = [fmt(q, pair_pos[q], pair_neg[q], pair_examples.get(q))
             for q in sorted(set(pair_pos) | set(pair_neg))]
    triples = [fmt(q, triple_pos[q], triple_neg[q], triple_examples.get(q)) for q in sorted(candidates)]
    optional_pvals(pairs, n_pos, n_neg)
    optional_pvals(triples, n_pos, n_neg, conditional=True)
    pairs.sort(key=lambda x: (-x['fraud'], x['legit'], x['pattern']))
    triples.sort(key=lambda x: (-x['fraud'], x['legit'], x['pattern']))
    common = ['pattern','length','fraud','legit','precision_in_sample','relative_frequency',
              'lift_in_sample','example_client','example_times','intermediate_events','p_fisher']
    write_csv(out / 'pairs.csv', pairs, common + ['q_bh'])
    write_csv(out / 'triples.csv', triples, common + ['q_bh_conditional'])
    report = {'clients': len(histories), 'positive_clients': n_pos, 'negative_clients': n_neg,
              'window_hours': window_hours, 'history_hours': history_hours,
              'pairs': len(pairs), 'triples_observed_in_fraud': len(triple_pos),
              'triples_with_min_support': len(triples),
              'statistical_note': 'Triple FDR conditional on screening positives; exploratory only.'}
    (out / 'mining_summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--window-hours', type=float, default=24)
    p.add_argument('--history-hours', type=float, default=48)
    p.add_argument('--min-positive-support', type=int, default=5)
    p.add_argument('--max-patterns', type=int, default=300000)
    a = p.parse_args()
    mine(a.db, a.out, a.window_hours, a.history_hours, a.min_positive_support, a.max_patterns)
