#!/usr/bin/env python3
"""Compile selected SQL predicates into a deployment-style SQLite event view.

The generated selected view is separate from the reference rule and contains
only observable current/past-event conditions; outcome labels are prohibited.
"""
import argparse
import json
from pathlib import Path
import re


def sql_string(value):
    return "'" + value.replace("'", "''") + "'"


def compile_rule(selection_file, candidate_file, baseline_rule_file, out_dir):
    selection = json.loads(Path(selection_file).read_text(encoding='utf-8'))
    candidates = json.loads(Path(candidate_file).read_text(encoding='utf-8'))['candidates']
    by_name = {x['name']: x['expression'] for x in candidates}
    chosen = selection['selected']
    if not chosen:
        raise ValueError('Selected rule is empty')
    if len(chosen) != len(set(chosen)) or any(n not in by_name for n in chosen):
        raise ValueError('Duplicate/missing candidate names')
    pieces = []
    for i, name in enumerate(chosen, 1):
        expr = by_name[name].strip()
        if not expr or any(x in expr for x in [';', '--', '/*', '*/']):
            raise ValueError('Unsafe candidate SQL for ' + name)
        if re.search(r'\b(fraud_time|source_fraud|last_resol|is_fraud|actual_fraud)\b', expr, re.I):
            raise ValueError('Outcome leakage in ' + name)
        pieces.append((f'g{i}_selected', name, expr))
    base = Path(baseline_rule_file).read_text(encoding='utf-8').split(
        '-- Просмотр сработок на УРОВНЕ СОБЫТИЙ')[0]
    exprs = [f'CASE WHEN ({expr}) THEN 1 ELSE 0 END AS {group}' for group, _, expr in pieces]
    combined = ' OR\n            '.join(f'({expr})' for _, _, expr in pieces)
    triggered = ' ||\n        '.join(
        f"(CASE WHEN ({expr}) THEN {sql_string(name + chr(44))} ELSE '' END)"
        for _, name, expr in pieces)
    # Reuse base view for its numeric normalization and frozen baseline flags.
    # Do not select e.*: that would duplicate the baseline antifraud_flag name.
    out_sql = (base + '''\n-- Generated rule built from selected, observable candidate expressions.\n'''
               '''DROP VIEW IF EXISTS antifraud_selected_event_flags;\n'''
               '''CREATE VIEW antifraud_selected_event_flags AS\nSELECT\n'''
               '''    e.event_row_id, e.epk_id, e.event_time, e.event_type, e.sub_type,\n'''
               '''    e.dsl_score, e.amount_rub,\n'''
               + ',\n'.join('    ' + expr for expr in exprs) + ',\n'
               + '    CASE WHEN (\n            ' + combined + '\n    ) THEN 1 ELSE 0 END AS antifraud_flag,\n'
               + '    RTRIM(\n        ' + triggered + ",\n        ','\n    ) AS triggered_groups\n"
               + 'FROM antifraud_event_flags AS e;\n')
    # SQL string concatenation must be self-contained, portable for SQLite.
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'selected_rule.sql').write_text(out_sql, encoding='utf-8')
    bank = ['ИССЛЕДОВАТЕЛЬСКОЕ ПРАВИЛО, автоматически сформировано из выбранных SQL-кандидатов.',
            'Условия проверяются на текущем событии и доступной прошлой истории. Все группы соединены через ИЛИ.',
            'Семантику каждого выражения и временные окна следует согласовать до внедрения.', '']
    descriptions = []
    for i, (flag, name, expression) in enumerate(pieces, 1):
        bank.extend([f'Группа {i}. {name}', expression, 'ИЛИ' if i < len(pieces) else '', ''])
        descriptions.append({'id': 'G' + str(i), 'title': name, 'kind': 'SQL-кандидат',
                             'condition': expression, 'sequence': '',
                             'meaning': 'Условие получено в исследовательском поиске; проверить предметную интерпретацию.',
                             'caveat': 'Требует независимой проверки, в том числе раннего Recall и стоимости FP.'})
    (out / 'selected_rule_banking.txt').write_text('\n'.join(bank), encoding='utf-8')
    (out / 'selected_rule_descriptions.json').write_text(
        json.dumps(descriptions, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Compiled', len(pieces), 'predicates to', out / 'selected_rule.sql')
    return out_sql


if __name__ == '__main__':
    base = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--selection', required=True)
    p.add_argument('--candidates', required=True)
    p.add_argument('--baseline-sql', default=str(base / 'assets/reference_rule_sqlite.sql'))
    p.add_argument('--out', required=True)
    a = p.parse_args()
    compile_rule(a.selection, a.candidates, a.baseline_sql, a.out)
