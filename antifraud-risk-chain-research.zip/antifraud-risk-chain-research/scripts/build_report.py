#!/usr/bin/env python3
"""Create a self-contained HTML research report from verified metrics and rule assets."""
import argparse
import csv
from datetime import date
import html
import json
from pathlib import Path


def esc(value):
    return html.escape(str(value if value is not None else ''))


def table(rows, columns):
    head=''.join(f'<th>{esc(display)}</th>' for key,display in columns)
    body=''.join('<tr>'+''.join(f'<td>{esc(row.get(key, ""))}</td>' for key,_ in columns)+'</tr>' for row in rows)
    return '<div class="table-scroll"><table><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table></div>'


def build(metrics_path, contributions_path, rules_path, sql_path, output, pairs=None, triples=None,
          descriptions_path=None, title='Исследование рисковых цепочек банковских событий'):
    metrics=json.loads(Path(metrics_path).read_text(encoding='utf-8'))
    with open(contributions_path,encoding='utf-8-sig',newline='') as stream:
        contribution=list(csv.DictReader(stream))
    descriptions=json.loads(Path(descriptions_path).read_text(encoding='utf-8')) if descriptions_path else []
    texts={item['id']:item for item in descriptions}
    historical=metrics['protocols']['historical_48h']
    fmt=lambda num: f'{100*num:.2f}%' if isinstance(num,(int,float)) else 'N/A'
    cards=''.join('<div class="metric"><small>'+esc(name)+'</small><b>'+esc(value)+'</b></div>' for name,value in [
        ('Recall, исследовательский',fmt(historical['recall'])),
        ('Precision, исследовательский',fmt(historical['precision'])),
        ('Ранний Recall ≥1 мин',fmt(metrics['protocols']['early_1minute']['recall'])),
        ('Ложные срабатывания',historical['FP'])])
    branches=[]
    for i,row in enumerate(contribution,1):
        text=texts.get('G'+str(i),{})
        branches.append(f'''<article class="panel"><div class="eyebrow">Блок {i} · {esc(text.get('kind',''))}</div>
<h3>{esc(text.get('title',row['group']))}</h3><p><strong>Условие:</strong> <code>{esc(text.get('condition',row['group']))}</code></p>
<p class="seq">{esc(text.get('sequence',''))}</p><p><strong>Смысл:</strong> {esc(text.get('meaning','См. условия правила.'))}</p>
<p class="muted"><strong>Ограничение:</strong> {esc(text.get('caveat','Требуется проверка на легитимном контроле.'))}</p>
<p class="small">Клиенты: TP={esc(row['TP_total'])}, FP={esc(row['FP_total'])}. Дополнительный вклад в порядке 1→8: +{esc(row['TP_added'])} TP, +{esc(row['FP_added'])} FP.</p></article>''')
    protocol=[]
    for name,values in metrics['protocols'].items():
        protocol.append({'protocol':name,'TP':values['TP'],'FP':values['FP'],
                         'Recall':fmt(values['recall']),'Precision':fmt(values['precision']),
                         'FPR':fmt(values['FPR'])})
    def catalog(path,header):
        if not path or not Path(path).exists():return '<p class="muted">Каталог не представлен.</p>'
        with open(path,encoding='utf-8-sig',newline='') as f: items=list(csv.DictReader(f))[:12]
        return '<h3>'+esc(header)+'</h3>'+table(items,[('pattern','Цепочка'),('fraud','Фрод'),('legit','Легитимные'),('precision_in_sample','Precision')])
    banking=Path(rules_path).read_text(encoding='utf-8')
    sql=Path(sql_path).read_text(encoding='utf-8')
    result=f'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title><style>
:root{{--ink:#14243b;--sub:#52647c;--border:#dce5ed;--sea:#0d857e;--pale:#edf6f6}}
*{{box-sizing:border-box}}body{{font:16px/1.62 system-ui,-apple-system,'Segoe UI',sans-serif;margin:0;background:#f3f6fa;color:var(--ink)}}
main{{max-width:1160px;margin:auto;background:white;padding:45px 48px 75px;box-shadow:0 8px 45px #14243b0c}}
header{{background:#11243b;color:white;border-radius:20px;padding:38px 42px;margin-bottom:42px}}
header p{{color:#d8e5ed}}h1{{font-size:32px;line-height:1.15}}h2{{font-size:26px;margin-top:42px;padding-bottom:12px;border-bottom:1px solid var(--border)}}
h3{{margin:0 0 12px;font-size:19px}}p{{margin:9px 0 15px}}.eyebrow{{letter-spacing:.12em;text-transform:uppercase;color:var(--sea);font-weight:800;font-size:12px}}
.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}}.metric{{padding:20px;background:var(--pale);border-radius:12px}}.metric small{{display:block;color:var(--sub);font-size:12px}}.metric b{{font-size:25px}}
.panel{{padding:23px;margin:14px 0;border:1px solid var(--border);border-radius:14px;break-inside:avoid}}.seq{{background:var(--pale);padding:10px;border-radius:7px;font-weight:700}}
.muted,.small{{color:var(--sub)}}.small{{font-size:13px}}.notice{{border-left:4px solid var(--sea);background:#f0f8f7;padding:16px;margin:18px 0}}
.table-scroll{{overflow-x:auto}}table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{padding:10px 11px;border-bottom:1px solid var(--border);text-align:left}}th{{background:#eaf1f5}}
pre{{white-space:pre-wrap;word-break:break-word;max-height:620px;overflow:auto;background:#13253a;color:#e9f0f8;border-radius:12px;padding:20px;font-size:12px}}
code{{white-space:pre-wrap;word-break:break-word}}@media(max-width:720px){{main{{padding:14px}}header{{padding:22px}}.metrics{{grid-template-columns:repeat(2,1fr)}}}}@media print{{body{{background:white}}main{{box-shadow:none}}pre{{max-height:none}}}}
</style></head><body><main><header><div class="eyebrow">Методика антифрода · {date.today().isoformat()}</div><h1>{esc(title)}</h1>
<p>Поиск несмежных цепочек, интерпретируемое правило, SQL и проверка на уровне клиентов. Исследовательский статус.</p></header>
<h2>1. Ключевые результаты</h2><div class="metrics">{cards}</div><div class="notice">Все показатели пересчитаны из результатов данного запуска. Исторический 48-часовой протокол отражает оценку выбранного правила на той же выборке; он не является независимым испытанием.</div>
<h2>2. Источник и методика</h2><p>Событий: {esc(metrics['input']['events'])}; клиентов: {esc(metrics['input']['clients'])}; положительных: {esc(metrics['input']['positive_clients'])}; легитимных: {esc(metrics['input']['negative_clients'])}. Предсказания используют текущие/прошлые события. Исход fraud_time используется только в независимом по коду оценочном модуле для постановки границ и метрик.</p>
<h2>3. Найденные несмежные цепочки</h2><p>Узловые события могут разделяться другими операциями. Поддержка считается по уникальным клиентам. Указанные цепочки являются статистическими гипотезами; причинность не установлена.</p>{catalog(pairs,'Пары')}{catalog(triples,'Тройки')}
<h2>4. Логика восьми блоков</h2><p>Блоки независимы и соединены через логическое ИЛИ. Временные ограничения и пороги представлены точно; описания подтипов требуют проверки внутреннего справочника.</p>{''.join(branches)}
<h2>5. Вклад блоков</h2>{table(contribution,[('group','Группа'),('TP_total','TP блока'),('FP_total','FP блока'),('TP_added','Доп. TP'),('FP_added','Доп. FP')])}
<h2>6. Проверка качества</h2>{table(protocol,[('protocol','Протокол'),('TP','TP'),('FP','FP'),('Recall','Recall'),('Precision','Precision'),('FPR','FPR')])}
<p class="notice">Сопоставимые 48 часов и полная неделя дают разные FP; ранний Recall требует алерта минимум за минуту до фрода. Модель, параметры, отбор правил и пороги требуют отдельной клиентской/временной проверки перед эксплуатацией.</p>
<h2>7. Правило в банковском формате</h2><pre>{esc(banking)}</pre>
<h2>8. SQL</h2><pre>{esc(sql)}</pre><h2>9. Условия применимости</h2>
<p>Не использовать метки исхода в прогнозе. Не переносить точность с тестовой доли фрода на промышленный поток. До блокировок необходима независимая валидация, анализ пропущенных и ложных срабатываний, уточнение справочника и оценка стоимости реакции.</p></main></body></html>'''
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    Path(output).write_text(result,encoding='utf-8')
    print('HTML report:',output,'bytes:',Path(output).stat().st_size)


if __name__=='__main__':
    base=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--metrics',required=True)
    p.add_argument('--contributions',required=True)
    p.add_argument('--rules',default=str(base/'assets/reference_rule_banking.txt'))
    p.add_argument('--sql',default=str(base/'assets/reference_rule_sqlite.sql'))
    p.add_argument('--descriptions',default=str(base/'templates/branch_descriptions.json'))
    p.add_argument('--pairs')
    p.add_argument('--triples')
    p.add_argument('--title',default='Исследование рисковых цепочек банковских событий')
    p.add_argument('--output',required=True)
    a=p.parse_args()
    build(a.metrics,a.contributions,a.rules,a.sql,a.output,a.pairs,a.triples,a.descriptions,a.title)
