#!/usr/bin/env python3
"""Nested client-level ML benchmark without calendar/whole-export span features.

Retrospective positive windows end at first fraud_time; negative at a specified
observation endpoint (default last available event, a known sampling limitation).
Early mode excludes events within the last minute before the first fraud.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timedelta
import json
import math
from pathlib import Path
import sqlite3
import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import StratifiedKFold


def histories(db, early=False):
    conn = sqlite3.connect(db)
    cols = {r[1] for r in conn.execute('PRAGMA table_info(events)')}
    needed = {'epk_id', 'event_time', 'fraud_time', 'sub_type', 'event_type',
              'cards_dsl_model_risk_score', 'inrubles'}
    if needed - cols:
        raise ValueError('Missing: ' + ','.join(sorted(needed - cols)))
    channels = 'event_channel' if 'event_channel' in cols else "''"
    sql = f'SELECT epk_id,event_time,fraud_time,sub_type,event_type,{channels},cards_dsl_model_risk_score,inrubles FROM events'
    groups = defaultdict(list)
    for client, time, fraud, subtype, typ, channel, score, amount in conn.execute(sql):
        def num(s):
            if s is None or not str(s).strip():
                return None
            return float(str(s).replace(',', '.'))
        groups[str(client)].append((datetime.fromisoformat(time.replace('T',' ')),
                                    datetime.fromisoformat(fraud.replace('T',' ')) if fraud and fraud.strip() else None,
                                    subtype or '(EMPTY)', typ or '', channel or '', num(score), num(amount)))
    conn.close()
    ids, labels, features = [], [], []
    for client, seq in sorted(groups.items()):
        seq.sort(key=lambda r:r[0])
        frauds = [z[1] for z in seq if z[1] is not None]
        pos = bool(frauds)
        anchor = min(frauds) if pos else seq[-1][0]
        latest = anchor - timedelta(minutes=1) if pos and early else anchor
        seq = [r for r in seq if anchor-timedelta(hours=48) <= r[0] <= latest]
        if not seq:
            vals = {'score_observed': 0., 'amount_observed': 0.}
        else:
            scores = [r[5] for r in seq if r[5] is not None]
            amounts = [r[6] for r in seq if r[6] is not None]
            cs = Counter(r[2] for r in seq)
            ct = Counter(r[3] for r in seq)
            ch = Counter(r[4] for r in seq)
            vals = {'events48':len(seq), 'unique_subtypes':len(cs), 'unique_channels':len(ch),
                    'score_observed':len(scores), 'score_missing_fraction':1-len(scores)/len(seq),
                    'score_max':max(scores,default=0), 'score_mean':sum(scores)/len(scores) if scores else 0,
                    'amount_observed':len(amounts), 'amount_sum':sum(max(0, x) for x in amounts),
                    'amount_max':max(amounts,default=0),
                    'money_count':sum(ct.get(t,0) for t in ['PAYMENT','WITHDRAW','DEPOSIT']),
                    'score_ge_300':sum(z>=300 for z in scores),
                    'score_ge_400':sum(z>=400 for z in scores),
                    'score_ge_500':sum(z>=500 for z in scores),
                    'score_ge_600':sum(z>=600 for z in scores),
                    'score_ge_700':sum(z>=700 for z in scores),
                    'score_ge_800':sum(z>=800 for z in scores),
                    'amount_ge_1000':sum(z>=1000 for z in amounts),
                    'amount_ge_10000':sum(z>=10000 for z in amounts),
                    'repeat_max':max(cs.values(),default=0),
                    'max_score_jump':max((b-a for a,b in zip(scores,scores[1:])),default=0)}
            # Event-window intensity uses only observed timestamps, no full-data span.
            start60 = 0
            max60 = 0
            for end in range(len(seq)):
                while seq[end][0]-seq[start60][0]>timedelta(minutes=60):
                    start60 += 1
                max60 = max(max60,end-start60+1)
            vals['max_events_60min'] = max60
            for key, n in cs.items():
                vals['sub_count:'+key] = n
            for key, n in ct.items():
                vals['type_count:'+key] = n
            for key, n in ch.items():
                vals['channel_count:'+key] = n
        ids.append(client)
        labels.append(int(pos))
        features.append(vals)
    return ids, np.array(labels,dtype=int), features


def factory(name):
    if name == 'decision_tree':
        from sklearn.tree import DecisionTreeClassifier
        return DecisionTreeClassifier(max_depth=5,min_samples_leaf=12,class_weight='balanced',random_state=11)
    if name == 'random_forest':
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(n_estimators=180,max_depth=7,min_samples_leaf=5,
                                      class_weight='balanced_subsample',n_jobs=2,random_state=11)
    if name == 'extra_trees':
        from sklearn.ensemble import ExtraTreesClassifier
        return ExtraTreesClassifier(n_estimators=180,max_depth=9,min_samples_leaf=4,
                                    class_weight='balanced',n_jobs=2,random_state=11)
    if name == 'hist_gradient_boost':
        from sklearn.ensemble import HistGradientBoostingClassifier
        return HistGradientBoostingClassifier(max_iter=140,max_leaf_nodes=8,min_samples_leaf=12,
                                              learning_rate=.045,l2_regularization=10,random_state=11)
    if name == 'catboost':
        from catboost import CatBoostClassifier
        return CatBoostClassifier(iterations=220,depth=4,learning_rate=.045,l2_leaf_reg=8,
                                  verbose=False,thread_count=2,random_seed=11)
    if name == 'lightgbm':
        from lightgbm import LGBMClassifier
        return LGBMClassifier(n_estimators=170,num_leaves=9,max_depth=5,min_child_samples=15,
                              learning_rate=.045,reg_lambda=8,verbosity=-1,n_jobs=2,random_state=11)
    if name == 'xgboost':
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=170,max_depth=3,min_child_weight=9,learning_rate=.045,
                             subsample=.85,colsample_bytree=.8,reg_lambda=10,eval_metric='logloss',n_jobs=2,random_state=11)
    if name == 'logistic_l1':
        from sklearn.linear_model import LogisticRegression
        return LogisticRegression(penalty='l1',solver='liblinear',C=.03,class_weight='balanced',max_iter=500,random_state=11)
    raise ValueError('Unknown model: '+name)


def fit_predict(name, train_features, train_labels, test_features):
    from sklearn.preprocessing import StandardScaler
    vectorizer=DictVectorizer(sparse=False)
    x=vectorizer.fit_transform(train_features)
    xt=vectorizer.transform(test_features)
    if name=='logistic_l1':
        scaler=StandardScaler().fit(x)
        x,xt=scaler.transform(x),scaler.transform(xt)
    model=factory(name)
    model.fit(x,train_labels)
    return model.predict_proba(xt)[:,1]


def threshold(probs, labels, target):
    positives=sorted((float(p) for p,y in zip(probs,labels) if y==1),reverse=True)
    if not positives:
        raise ValueError('No positive clients inside training threshold fold')
    count=max(1,math.ceil(len(positives)*target))
    return positives[count-1]-1e-12


def benchmark(db,out,models,early=False,folds=5,inner=3,target=.75):
    out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    ids,y,features=histories(db,early)
    outer=StratifiedKFold(n_splits=folds,shuffle=True,random_state=20260921)
    reports=[]
    for name in models:
        predictions=np.zeros(len(y),dtype=bool)
        thresholds=[]
        try:
            for fold,(train,test) in enumerate(outer.split(np.arange(len(y)),y)):
                inner_cv=StratifiedKFold(n_splits=inner,shuffle=True,random_state=300+fold)
                oof=np.zeros(len(train),dtype=float)
                for a,b in inner_cv.split(np.arange(len(train)),y[train]):
                    oof[b]=fit_predict(name,[features[train[j]] for j in a],y[train[a]],
                                       [features[train[j]] for j in b])
                th=threshold(oof,y[train],target)
                probability=fit_predict(name,[features[j] for j in train],y[train],
                                         [features[j] for j in test])
                predictions[test]=probability>=th
                thresholds.append(th)
            tp=int(np.sum(predictions&(y==1)))
            fp=int(np.sum(predictions&(y==0)))
            row={'model':name,'status':'completed','target_inner_recall':target,
                 'TP':tp,'FP':fp,'FN':int(sum(y)-tp),'TN':int(sum(1-y)-fp),
                 'recall':tp/int(sum(y)), 'precision':tp/(tp+fp) if tp+fp else None,
                 'thresholds':thresholds,'mode':'early_1min' if early else 'current'}
        except (ImportError, ModuleNotFoundError) as exc:
            row={'model':name,'status':'not_run_missing_dependency','reason':str(exc)}
        reports.append(row)
        print(json.dumps(row,ensure_ascii=False))
    (out/'ml_results.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'ml_results.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=['model','status','target_inner_recall','TP','FP','FN','TN','recall','precision','mode'],extrasaction='ignore')
        writer.writeheader();writer.writerows(reports)
    return reports


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--models',default='decision_tree,random_forest,extra_trees,hist_gradient_boost,catboost,lightgbm,xgboost,logistic_l1')
    p.add_argument('--folds',type=int,default=5)
    p.add_argument('--inner',type=int,default=3)
    p.add_argument('--target-inner-recall',type=float,default=.75)
    p.add_argument('--early',action='store_true')
    a=p.parse_args()
    benchmark(a.db,a.out,[m.strip() for m in a.models.split(',') if m.strip()],a.early,a.folds,a.inner,a.target_inner_recall)
