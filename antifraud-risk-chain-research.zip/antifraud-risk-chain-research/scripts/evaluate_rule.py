#!/usr/bin/env python3
"""Evaluate frozen eight-branch SQLite rule; labels appear ONLY in this offline evaluator."""
import argparse
from bisect import bisect_left, bisect_right
from collections import defaultdict
import csv
from datetime import datetime, timedelta
import json
import re
import sqlite3
from pathlib import Path

GROUPS = ['g1_atm_cash_48h', 'g2_epos_pos_payment', 'g3_epos_score',
          'g4_c2b_score', 'g5_score_amount', 'g6_rurpayjursb',
          'g7_vk_without_otp', 'g8_account_epos']


def dt(value):
    return datetime.fromisoformat(value.replace('T', ' '))


def stats(rows):
    tp = sum(p and y for y, p in rows)
    fp = sum(p and not y for y, p in rows)
    fn = sum(y and not p for y, p in rows)
    tn = sum(not y and not p for y, p in rows)
    div = lambda a, b: a / b if b else None
    return {'TP': tp, 'FP': fp, 'FN': fn, 'TN': tn,
            'recall': div(tp, tp + fn), 'precision': div(tp, tp + fp),
            'F1': div(2 * tp, 2 * tp + fp + fn),
            'FPR': div(fp, fp + tn), 'lift': div(div(tp, tp + fp), div(tp + fn, len(rows)))}


def check_numbers(connection):
    invalid = {'cards_dsl_model_risk_score': [], 'inrubles': []}
    for value_score, value_amount in connection.execute(
            'SELECT cards_dsl_model_risk_score,inrubles FROM events'):
        for key, value in [('cards_dsl_model_risk_score', value_score), ('inrubles', value_amount)]:
            if value is None or not str(value).strip():
                continue
            try:
                float(str(value).replace(',', '.'))
            except (ValueError, TypeError):
                if len(invalid[key]) < 5:
                    invalid[key].append(str(value))
    if any(invalid.values()):
        raise ValueError(f'Non-numeric score/amount values; define a parsing policy: {invalid}')


def evaluate(db_path, rule_path, out_dir, expect_reference=False, view='antifraud_event_flags'):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(db_path)
    try:
        columns = {r[1] for r in db.execute('PRAGMA table_info(events)')}
        needed = {'epk_id', 'event_time', 'sub_type', 'event_type',
                  'cards_dsl_model_risk_score', 'inrubles', 'fraud_time'}
        missing = needed - columns
        if missing:
            raise ValueError('Missing columns: ' + ','.join(sorted(missing)))
        check_numbers(db)
        rule = Path(rule_path).read_text(encoding='utf-8-sig')
        # Prediction script contains a demo SELECT after the CREATE VIEW, not part of the definition.
        ddl = rule.split('-- Просмотр сработок на УРОВНЕ СОБЫТИЙ')[0]
        lowered = ddl.lower()
        for label in ('fraud_time', 'source_fraud', 'last_resol', 'is_fraud'):
            # The reference SQL mentions label names only in comments; strip comments first.
            uncommented = '\n'.join(line for line in lowered.splitlines()
                                      if not line.lstrip().startswith('--'))
            if label in uncommented:
                raise ValueError('Outcome leakage into prediction SQL: ' + label)
        db.executescript(ddl)
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', view):
            raise ValueError('Invalid SQL view name')
        groups = [r[1] for r in db.execute(f'PRAGMA table_info({view})') if re.match(r'^g[0-9]+_', r[1])] 
        if not groups:
            raise ValueError(f'No gN_ columns in view {view}')
        g1idx = groups.index('g1_atm_cash_48h') if 'g1_atm_cash_48h' in groups else None
        raw = defaultdict(list)
        for rowid, client, time, label, subtype in db.execute(
                'SELECT rowid, epk_id,event_time,fraud_time,sub_type FROM events'):
            if not client or not time:
                raise ValueError(f'Empty epk_id/event_time at rowid={rowid}')
            raw[str(client)].append({'id': rowid, 'time': dt(time), 'fraud': dt(label) if label and str(label).strip() else None, 'sub': subtype})
        # Materialize flags once, preserving each original row. No outcomes in this query.
        projection = ','.join(groups)
        flags = {}
        for row in db.execute('SELECT event_row_id,' + projection + f' FROM {view}'):
            flags[row[0]] = tuple(bool(x) for x in row[1:])
        if sum(map(len, raw.values())) != len(flags):
            raise AssertionError('SQL view lost or multiplied input event rows')
        all_rows = []
        contributions = [[0] * 4 for _ in groups]  # TP_total FP_total TP_added FP_added
        observed = {'historical_48h': [], 'working_sql_48h': [],
                    'negative_full_history': [], 'early_1minute': []}
        early_ids = []
        for client, events in sorted(raw.items()):
            events.sort(key=lambda r: (r['time'], r['id']))
            fraud_times = [r['fraud'] for r in events if r['fraud'] is not None]
            label = bool(fraud_times)
            fraud_time = min(fraud_times) if label else None
            anchor = fraud_time or events[-1]['time']
            start = anchor - timedelta(hours=48)
            scoped = [r for r in events if start <= r['time'] <= anchor]
            atm = sorted(r['time'] for r in scoped if r['sub'] == 'ATM_CASH')
            # Historical branch G1 counts only the eval-scoped ATM events; G2..G8 are
            # from the full past as-of SQL, allowing A before the eval-window start.
            scoped_flags = {}
            for event in scoped:
                src = list(flags[event['id']])
                if g1idx is not None:
                    src[g1idx] = bisect_right(atm, event['time']) - bisect_left(atm, event['time'] - timedelta(hours=48)) >= 2
                scoped_flags[event['id']] = tuple(src)
            historical_active = [r for r in scoped if any(scoped_flags[r['id']])]
            working_active = [r for r in scoped if any(flags[r['id']])]
            week_active = [r for r in (scoped if label else events) if any(flags[r['id']])]
            early_active = [r for r in historical_active if (not label or r['time'] <= fraud_time - timedelta(minutes=1))]
            detected_historical = bool(historical_active)
            detected_working = bool(working_active)
            detected_week = bool(week_active)
            detected_early = bool(early_active)
            observed['historical_48h'].append((label, detected_historical))
            observed['working_sql_48h'].append((label, detected_working))
            observed['negative_full_history'].append((label, detected_week))
            observed['early_1minute'].append((label, detected_early))
            if label and detected_early:
                early_ids.append(client)
            client_groups = [any(scoped_flags[r['id']][i] for r in scoped) for i in range(len(groups))]
            for i, hit in enumerate(client_groups):
                if not hit:
                    continue
                contributions[i][0 if label else 1] += 1
                if not any(client_groups[:i]):
                    contributions[i][2 if label else 3] += 1
            all_rows.append({'epk_id': client, 'actual_fraud': int(label),
                             'fraud_time': fraud_time.isoformat(sep=' ') if fraud_time else '',
                             'client_flag_historical_48h': int(detected_historical),
                             'client_flag_working_48h': int(detected_working),
                             'client_flag_negative_full_history': int(detected_week),
                             'client_flag_early_1minute': int(detected_early),
                             'first_alert': min((r['time'] for r in historical_active), default=None).isoformat(sep=' ') if historical_active else ''})
        results = {name: stats(rows) for name, rows in observed.items()}
        total_pos = sum(r['actual_fraud'] for r in all_rows)
        total_neg = len(all_rows) - total_pos
        for name, metric in results.items():
            assert metric['TP'] + metric['FN'] == total_pos, name
            assert metric['FP'] + metric['TN'] == total_neg, name
        original = results['historical_48h']
        assert sum(row[2] for row in contributions) == original['TP']
        assert sum(row[3] for row in contributions) == original['FP']
        result = {'input': {'events': len(flags), 'clients': len(raw),
                            'positive_clients': total_pos, 'negative_clients': total_neg},
                  'protocols': results,
                  'limitations': ['historical_48h is resubstitution after choosing the eight clauses',
                                  'working_sql_48h differs from historical on G1 pre-window history',
                                  'early_1minute requires alert at least 60 seconds before fraud',
                                  'negative_full_history has a longer negative exposure']}
        (out / 'metrics.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        with (out / 'rule_contributions.csv').open('w', newline='', encoding='utf-8-sig') as stream:
            writer = csv.writer(stream)
            writer.writerow(['group', 'TP_total', 'FP_total', 'TP_added', 'FP_added'])
            writer.writerows(([name, *row] for name, row in zip(groups, contributions)))
        with (out / 'client_predictions.csv').open('w', newline='', encoding='utf-8-sig') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(all_rows[0]))
            writer.writeheader()
            writer.writerows(all_rows)
        if expect_reference:
            assert groups == GROUPS, 'Reference check requires all eight reference branches'
            assert result['input'] == {'events': 37791, 'clients': 1000,
                                        'positive_clients': 100, 'negative_clients': 900}
            assert (original['TP'], original['FP'], original['FN'], original['TN']) == (70, 47, 30, 853)
            assert results['working_sql_48h']['FP'] == 55
            assert results['negative_full_history']['FP'] == 145
            assert results['early_1minute']['TP'] == 40
            assert [row[2] for row in contributions] == [3, 11, 30, 6, 10, 4, 2, 4]
            print('REFERENCE CHECK: PASS')
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return result
    finally:
        db.close()


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db', required=True)
    p.add_argument('--rule', default=str(Path(__file__).resolve().parents[1] / 'assets/reference_rule_sqlite.sql'))
    p.add_argument('--output', required=True)
    p.add_argument('--expect-reference', action='store_true')
    p.add_argument('--view', default='antifraud_event_flags', help='Name of the view holding gN_ flags and event_row_id')
    a = p.parse_args()
    evaluate(a.db, a.rule, a.output, a.expect_reference, a.view)
