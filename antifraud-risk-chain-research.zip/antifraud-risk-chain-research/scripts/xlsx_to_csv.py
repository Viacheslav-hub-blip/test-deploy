#!/usr/bin/env python3
"""Streaming XLSX -> CSV using Python stdlib ZIP/XML readers, no Excel runtime.

Only worksheet *values* are transferred (not formulas or formatting). Handles
inline and shared strings, numeric and empty cells; converts Excel date serials
for event_time/fraud_time when necessary. Designed for flat bank-event sheets.
"""
import argparse
import csv
from datetime import datetime, timedelta
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'


def col_index(cell_ref):
    letters = re.match(r'[A-Z]+', cell_ref)
    if letters is None:
        raise ValueError('Missing A1 coordinate: ' + str(cell_ref))
    ix = 0
    for char in letters.group():
        ix = ix * 26 + ord(char) - 64
    return ix - 1


def shared_strings(archive):
    if 'xl/sharedStrings.xml' not in archive.namelist():
        return []
    strings = []
    with archive.open('xl/sharedStrings.xml') as stream:
        for _, elem in ET.iterparse(stream, events=('end',)):
            if elem.tag == NS + 'si':
                strings.append(''.join(node.text or '' for node in elem.iter(NS + 't')))
                elem.clear()
    return strings


def excel_datetime(serial):
    return (datetime(1899, 12, 30) + timedelta(days=float(serial))).isoformat(sep=' ', timespec='seconds')


def decode(cell, lookup, date_column=False):
    kind = cell.get('t', '')
    if kind == 'inlineStr':
        internal = cell.find(NS + 'is')
        return ''.join(item.text or '' for item in internal.iter(NS + 't')) if internal is not None else ''
    value = cell.find(NS + 'v')
    if value is None or value.text is None:
        return ''
    raw = value.text
    if kind == 's':
        return lookup[int(raw)]
    if kind == 'b':
        return '1' if raw == '1' else '0'
    if date_column and kind not in ('str', 'e'):
        try:
            if float(raw) > 1000:
                return excel_datetime(raw)
        except ValueError:
            pass
    return raw


def convert(xlsx, output, sheet_index=0, last_row=None, column_count=20, chunk_size=None):
    # chunk_size accepted for compatibility with earlier CLI; parser is inherently streaming.
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    worksheet_name = f'xl/worksheets/sheet{sheet_index + 1}.xml'
    count = 0
    with zipfile.ZipFile(xlsx) as archive:
        if worksheet_name not in archive.namelist():
            raise ValueError('Worksheet XML not found: ' + worksheet_name)
        strings = shared_strings(archive)
        with archive.open(worksheet_name) as source, path.open('w', encoding='utf-8-sig', newline='') as target:
            writer = csv.writer(target)
            header = None
            for _, element in ET.iterparse(source, events=('end',)):
                if element.tag != NS + 'row':
                    continue
                row_number = int(element.get('r') or count + 1)
                if last_row is not None and row_number > last_row:
                    break
                cells = {}
                for cell in element:
                    if cell.tag == NS + 'c':
                        ix = col_index(cell.get('r', 'A1'))
                        if column_count is None or ix < column_count:
                            cells[ix] = cell
                if header is None:
                    ncols = column_count or (max(cells) + 1 if cells else 0)
                    header = [decode(cells[j], strings) if j in cells else '' for j in range(ncols)]
                    if not header[0] or len(header) != len(set(header)) or 'epk_id' not in header:
                        raise ValueError('Invalid header/epk_id; check sheet and --columns')
                    writer.writerow(header)
                else:
                    values = [decode(cells[j], strings, header[j] in ('event_time', 'fraud_time'))
                              if j in cells else '' for j in range(len(header))]
                    if values[0] == '':
                        raise ValueError(f'Empty epk_id in XLSX row {row_number}')
                    writer.writerow(values)
                    count += 1
                element.clear()
    print(f'XLSX -> CSV: {count} rows, {len(header or [])} columns -> {path}')
    return count


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--xlsx', required=True)
    p.add_argument('--csv', required=True)
    p.add_argument('--sheet-index', type=int, default=0,
                   help='Sheet index in ordinary sheet1.xml ordering; inspect workbook.xml for complex workbooks')
    p.add_argument('--last-row', type=int, help='Last Excel row including header; omit for all rows')
    p.add_argument('--columns', type=int, default=20, help='Number of source columns; omit/0 for autodetect')
    p.add_argument('--chunk-size', type=int, default=None, help='Ignored; streaming reader uses constant row memory')
    a = p.parse_args()
    convert(a.xlsx, a.csv, a.sheet_index, a.last_row, a.columns or None, a.chunk_size)
