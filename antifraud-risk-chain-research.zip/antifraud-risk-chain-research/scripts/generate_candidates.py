#!/usr/bin/env python3
"""Generate a reusable pool of SQL rule hypotheses from frequent observed patterns.

Default pairs are screened ONLY on total client support (fraud+legit), not lift.
Triples were screened by positive support upstream: use --include-triples only
for exploratory work, never claim a fully nested fold-refit without regenerating
this candidate pool separately inside every training fold.
"""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import sqlite3


def sql_quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def load(path):
    if not path:
        return []
    with open(path,encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))


def generate(db, out, pairs=None, triples=None, include_triples=False,
             max_types=16, max_pairs=18, max_triples=8, min_pair_support=15):
    conn=sqlite3.connect(db)
    counts=Counter()
    for subtype, n in conn.execute('SELECT sub_type,COUNT(*) FROM events GROUP BY sub_type'):
        if subtype:
            counts[subtype] = n
    conn.close()
    types=[s for s,_ in counts.most_common(max_types)]
    candidates=[]
    seen=set()
    def add(name,expr):
        if name not in seen:
            candidates.append({'name':name,'expression':expr})
            seen.add(name)
    for i,name in enumerate(['g1_atm_cash_48h','g2_epos_pos_payment','g3_epos_score',
                              'g4_c2b_score','g5_score_amount','g6_rurpayjursb',
                              'g7_vk_without_otp','g8_account_epos'],1):
        add('G'+str(i)+'_REFERENCE',f'e.{name}=1')
    for subtype in types:
        for score in [300,400,500,600,800]:
            add(f'sub:{subtype}:score>={score}',f'e.sub_type={sql_quote(subtype)} AND e.dsl_score>={score}')
    for score in [300,400,500,600,700,800]:
        for amount in [500,1000,5000]:
            add(f'score>={score}:amount>={amount}',f'e.dsl_score>={score} AND e.amount_rub>={amount}')
    pair_rows=sorted(load(pairs),key=lambda r:(-(int(r['fraud'])+int(r['legit'])),r['pattern']))
    pairs_selected=0
    for row in pair_rows:
        if int(row['fraud'])+int(row['legit']) < min_pair_support:
            continue
        parts=row['pattern'].split(' -> ')
        if len(parts)!=2:
            continue
        a,b=parts
        aq,bq=map(sql_quote,parts)
        for score in [300,400,500]:
            expr=(f'e.sub_type={bq} AND e.dsl_score>={score} AND EXISTS '
                  f'(SELECT 1 FROM events a WHERE a.epk_id=e.epk_id AND a.sub_type={aq} '
                  "AND a.event_time<e.event_time AND a.event_time>=datetime(e.event_time,'-24 hours'))")
            add(f'PAIR {a} -> {b} score>={score}',expr)
        pairs_selected+=1
        if pairs_selected>=max_pairs:
            break
    triples_selected=0
    if include_triples:
        tri=sorted(load(triples),key=lambda r:(-int(r['fraud']),int(r['legit']),r['pattern']))
        for row in tri:
            parts=row['pattern'].split(' -> ')
            if len(parts)!=3:
                continue
            a,b,c=parts
            aq,bq,cq=map(sql_quote,parts)
            for score in [400,500]:
                expr=(f'e.sub_type={cq} AND e.dsl_score>={score} AND EXISTS '
                      f'(SELECT 1 FROM events b WHERE b.epk_id=e.epk_id AND b.sub_type={bq} '
                      "AND b.event_time<e.event_time AND b.event_time>=datetime(e.event_time,'-24 hours') "
                      f'AND EXISTS (SELECT 1 FROM events a WHERE a.epk_id=e.epk_id AND a.sub_type={aq} '
                      "AND a.event_time<b.event_time AND a.event_time>=datetime(e.event_time,'-24 hours')))")
                add(f'TRIPLE {a} -> {b} -> {c} score>={score}',expr)
            triples_selected+=1
            if triples_selected>=max_triples:
                break
    result={'description':'Candidate pool generated from observed subtypes and unsupervised total pair support; triple screening (if any) is exploratory.',
            'candidates':candidates,'source_types':types,'source_pairs':pairs_selected,
            'source_triples':triples_selected,'must_regenerate_inside_train_for_fully_nested':include_triples}
    Path(out).parent.mkdir(parents=True,exist_ok=True)
    Path(out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Generated:',len(candidates),'candidates ->',out,'pairs',pairs_selected,'triples',triples_selected)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--pairs')
    p.add_argument('--triples')
    p.add_argument('--include-triples',action='store_true')
    p.add_argument('--max-types',type=int,default=16)
    p.add_argument('--max-pairs',type=int,default=18)
    p.add_argument('--max-triples',type=int,default=8)
    p.add_argument('--min-pair-support',type=int,default=15)
    a=p.parse_args()
    generate(a.db,a.out,a.pairs,a.triples,a.include_triples,a.max_types,a.max_pairs,a.max_triples,a.min_pair_support)
