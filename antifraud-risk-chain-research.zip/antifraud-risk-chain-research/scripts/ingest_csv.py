#!/usr/bin/env python3
"""Lossless CSV -> SQLite import for an event table. No labels are read as predictors."""
import argparse
import csv
import json
import sqlite3
from pathlib import Path

REQUIRED = {'epk_id', 'event_time', 'event_type', 'sub_type',
            'cards_dsl_model_risk_score', 'inrubles'}


def quote(identifier):
    return '"' + identifier.replace('"', '""') + '"'


def ingest(source, target):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError(f"Output DB already exists: {target}")
    with open(source, 'r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames or []
        if not columns or len(columns) != len(set(columns)):
            raise ValueError('Empty or duplicate CSV header')
        missing = REQUIRED - set(columns)
        if missing:
            raise ValueError(f'Missing required columns: {sorted(missing)}')
        connection = sqlite3.connect(target)
        try:
            ddl = ','.join(f'{quote(name)} TEXT' for name in columns)
            connection.execute(f'CREATE TABLE events ({ddl})')
            placeholders = ','.join('?' for _ in columns)
            sql = f'INSERT INTO events ({",".join(map(quote, columns))}) VALUES ({placeholders})'
            batch, total = [], 0
            for row in reader:
                if None in row:  # Detect more cells than defined columns.
                    raise ValueError(f'CSV row has too many cells at row {total + 2}')
                batch.append(tuple(row[key] for key in columns))
                if len(batch) >= 2000:
                    connection.executemany(sql, batch)
                    total += len(batch)
                    batch.clear()
            if batch:
                connection.executemany(sql, batch)
                total += len(batch)
            connection.execute('CREATE INDEX idx_client_time ON events(epk_id,event_time)')
            connection.execute('CREATE INDEX idx_client_subtype_time ON events(epk_id,sub_type,event_time)')
            n_clients = connection.execute('SELECT COUNT(DISTINCT epk_id) FROM events').fetchone()[0]
            n_fraud = None
            if 'fraud_time' in columns:
                n_fraud = connection.execute("SELECT COUNT(DISTINCT epk_id) FROM events WHERE fraud_time IS NOT NULL AND TRIM(fraud_time)<>''").fetchone()[0]
            connection.commit()
        except Exception:
            connection.close()
            target.unlink(missing_ok=True)
            raise
        finally:
            connection.close()
    stats = {'rows': total, 'clients': n_clients, 'fraud_clients': n_fraud,
             'columns': columns, 'sqlite_path': str(target)}
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    return stats


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', required=True)
    p.add_argument('--db', required=True)
    args = p.parse_args()
    ingest(args.csv, args.db)
