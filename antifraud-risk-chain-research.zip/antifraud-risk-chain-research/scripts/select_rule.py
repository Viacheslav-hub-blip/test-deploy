#!/usr/bin/env python3
"""Greedy interpretable OR-rule selection and client-level fold refit of SQL candidates.

Candidate predicates are SQL expressions over antifraud_eval_event_flags. This
sample JSON contains only the frozen 8 flags; for a NEW search, first add a
rich candidate set (new score thresholds/rolling counts/chains) to that view.
"""
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import random
import sqlite3


def metrics(mask, y):
    tp = sum(m and z for m, z in zip(mask, y))
    fp = sum(m and not z for m, z in zip(mask, y))
    p = sum(y)
    return {'TP': tp, 'FP': fp, 'FN': p - tp, 'TN': len(y) - p - fp,
            'recall': tp / p if p else None,
            'precision': tp / (tp + fp) if tp + fp else None}


def greed(masks, labels, eligible, target, penalty=.4, max_rules=12, min_gain=1):
    chosen = []
    union = [False] * len(labels)
    for _ in range(max_rules):
        if sum(z and f and ok for z, f, ok in zip(union, labels, eligible)) >= target:
            break
        scores = []
        for j, mask in enumerate(masks):
            newtp = sum(m and not u and y and ok for m, u, y, ok in zip(mask, union, labels, eligible))
            newfp = sum(m and not u and not y and ok for m, u, y, ok in zip(mask, union, labels, eligible))
            value = newtp / (newfp + 2) ** penalty - 0.015 * newfp if newtp >= min_gain and j not in chosen else float('-inf')
            scores.append(value)
        winner = max(range(len(scores)), key=lambda j: (scores[j], -j))
        if scores[winner] <= 0:
            break
        chosen.append(winner)
        union = [u or m for u, m in zip(union, masks[winner])]
    # Prune unnecessary clauses without losing target TP.
    for idx in chosen[::-1]:
        proposed = [any(masks[j][k] for j in chosen if j != idx) for k in range(len(labels))]
        if sum(z and f and ok for z, f, ok in zip(proposed, labels, eligible)) >= target:
            chosen.remove(idx)
            union = proposed
    return chosen, union


def stratified_folds(labels, k=5, seed=20260921):
    rng = random.Random(seed)
    folds = [[] for _ in range(k)]
    for outcome in (0, 1):
        group = [i for i, y in enumerate(labels) if y == outcome]
        rng.shuffle(group)
        for j, idx in enumerate(group):
            folds[j % k].append(idx)
    return [sorted(f) for f in folds]


def select(db_path, candidates_path, rule_path, validation_path, out, target_recall=.70, folds=5):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    candidates = json.loads(Path(candidates_path).read_text(encoding='utf-8'))['candidates']
    if not candidates:
        raise ValueError('No candidate rules supplied')
    conn = sqlite3.connect(db_path)
    try:
        sql = Path(rule_path).read_text(encoding='utf-8')
        conn.executescript(sql.split('-- Просмотр сработок на УРОВНЕ СОБЫТИЙ')[0])
        val = Path(validation_path).read_text(encoding='utf-8')
        conn.executescript(val.split('-- РЕЗУЛЬТАТ')[0])
        # This is OFFLINE selection: the outcome appears solely in this truth query.
        outcomes = {str(client): int(truth) for client, truth in conn.execute(
            "SELECT epk_id,MAX(CASE WHEN fraud_time IS NOT NULL AND TRIM(fraud_time)<>'' THEN 1 ELSE 0 END) FROM events GROUP BY epk_id")}
        ids = sorted(outcomes)
        labels = [outcomes[k] for k in ids]
        masks = []
        for item in candidates:
            expr = item['expression'].strip()
            if not expr or ';' in expr or '--' in expr or '/*' in expr:
                raise ValueError('Candidate expression must be one safe predicate without SQL statements')
            forbidden = ('fraud_time', 'source_fraud', 'last_resol', 'is_fraud', 'actual_fraud')
            if any(word in expr.lower() for word in forbidden):
                raise ValueError('Outcome leakage in candidate expression')
            query = f'SELECT e.epk_id,MAX(CASE WHEN ({expr}) THEN 1 ELSE 0 END) FROM antifraud_eval_event_flags AS e GROUP BY e.epk_id'
            m = dict(conn.execute(query))
            masks.append([bool(m.get(client, 0)) for client in ids])
    finally:
        conn.close()
    alternatives = []
    eligibility = [True] * len(ids)
    target = math.ceil(target_recall * sum(labels))
    for pen in [.2, .4, .6, .8, 1., 1.3]:
        for max_rules in [5, 8, 12, 18]:
            chosen, union = greed(masks, labels, eligibility, target, pen, max_rules)
            mt = metrics(union, labels)
            if mt['TP'] >= target:
                alternatives.append((mt['FP'], len(chosen), pen, chosen, mt))
    if not alternatives:
        raise ValueError('Candidate pool cannot reach the requested recall; expand candidates or report infeasibility')
    fp, _, penalty, chosen, empirical = min(alternatives, key=lambda x: (x[0], x[1], x[2]))
    running = [False] * len(ids)
    contributions = []
    for j in chosen:
        new = [z and not u for z, u in zip(masks[j], running)]
        whole = metrics(masks[j], labels)
        inc = metrics(new, labels)
        contributions.append({'name': candidates[j]['name'], 'full_TP': whole['TP'],
                              'full_FP': whole['FP'], 'new_TP': inc['TP'], 'new_FP': inc['FP']})
        running = [u or z for u, z in zip(running, masks[j])]
    # Fold-refit: candidate predicates fixed before CV, but their selected OR composition is refit.
    splits = stratified_folds(labels, folds)
    oof = [False] * len(ids)
    selected_by_fold = []
    for test in splits:
        heldout = set(test)
        train = [idx not in heldout for idx in range(len(ids))]
        p_train = sum(y and ok for y, ok in zip(labels, train))
        fold_target = math.ceil(target_recall * p_train)
        choice, union = greed(masks, labels, train, fold_target, penalty, 12, min_gain=1)
        for idx in test:
            oof[idx] = union[idx]
        selected_by_fold.append([candidates[j]['name'] for j in choice])
    report = {'candidate_count': len(candidates), 'target_recall': target_recall,
              'selected': [candidates[j]['name'] for j in chosen], 'penalty': penalty,
              'resubstitution': empirical, 'fold_refit': metrics(oof, labels),
              'folds': selected_by_fold, 'contributions': contributions,
              'warning': 'If candidates themselves were chosen using all labels, fold_refit is not fully nested. Historical rule metrics are exploratory.'}
    (out / 'selection.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    base = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db', required=True)
    p.add_argument('--candidates', default=str(base / 'templates/candidate_flags.json'))
    p.add_argument('--rule', default=str(base / 'assets/reference_rule_sqlite.sql'))
    p.add_argument('--validation', default=str(base / 'assets/reference_validation_sqlite.sql'))
    p.add_argument('--out', required=True)
    p.add_argument('--target-recall', type=float, default=.70)
    p.add_argument('--folds', type=int, default=5)
    a = p.parse_args()
    select(a.db, a.candidates, a.rule, a.validation, a.out, a.target_recall, a.folds)
