#!/usr/bin/env python3
"""Prefix-growth discovery of gapped 4/5-event sequences; bounded candidate search.

Top triples are a deliberate, documented candidate screen; output is NOT all
possible long patterns. Recompute screening inside training folds for full CV.
"""
import argparse
from collections import Counter
import csv
from datetime import timedelta
import json
from pathlib import Path
from mine_sequences import read_histories


def occurrences(seq, pattern, span, limit=2000):
    """Yield matching index tuples in strictly increasing timestamp order."""
    matches = []
    def walk(prefix, prev_index, first_time):
        if len(matches) >= limit:
            return
        if len(prefix) == len(pattern):
            matches.append(tuple(prefix))
            return
        start = prev_index + 1
        for j in range(start, len(seq)):
            tj, sub = seq[j]
            if first_time is not None and tj-first_time > span:
                break
            if sub != pattern[len(prefix)]:
                continue
            if prev_index >= 0 and tj <= seq[prev_index][0]:
                continue
            walk(prefix+[j],j,first_time if first_time is not None else tj)
            if len(matches) >= limit:
                break
    walk([], -1, None)
    return matches


def exists(seq, pattern, span):
    last=pattern[-1]
    for end in range(len(seq)):
        if seq[end][1]!=last:
            continue
        start_time=seq[end][0]-span
        index=0
        last_t=None
        for j in range(end):
            t,sub=seq[j]
            if t<start_time or sub!=pattern[index] or (last_t is not None and t<=last_t):
                continue
            last_t=t
            index+=1
            if index==len(pattern)-1:
                if t<seq[end][0]:
                    return True
                break
    return False


def grow(histories, seeds, length, span, max_occurrences=2000, max_candidates=30000):
    fraud_clients={client:seq for client,(y,seq) in histories.items() if y}
    counts=Counter()
    example={}
    for client,seq in fraud_clients.items():
        present=set()
        for seed in seeds:
            for prefix in occurrences(seq,seed,span,max_occurrences):
                last=prefix[-1]
                for j in range(last+1,len(seq)):
                    if seq[j][0]-seq[prefix[0]][0]>span:
                        break
                    if seq[j][0]<=seq[last][0]:
                        continue
                    key=seed+(seq[j][1],)
                    present.add(key)
                    example.setdefault(key,(client,seq[prefix[0]][0],seq[j][0]))
            if len(present)>max_candidates:
                raise ValueError('Long-sequence candidate explosion; reduce --max-seeds or max occurrences')
        counts.update(present)
    return counts,example


def write(path, candidates, examples, histories, min_support):
    legit=[seq for y,seq in histories.values() if not y]
    p=sum(y for y,_ in histories.values())
    n=len(legit)
    rows=[]
    for key,count in candidates.most_common():
        if count<min_support:
            continue
        fp=sum(exists(seq,key,timedelta(hours=24)) for seq in legit)
        rows.append({'pattern':' -> '.join(key),'length':len(key),'fraud':count,'legit':fp,
                     'precision_in_sample':count/(count+fp),
                     'relative_frequency':(count/p)/(fp/n) if fp else '',
                     'example_client':examples[key][0],
                     'first_time':examples[key][1].isoformat(sep=' '),
                     'last_time':examples[key][2].isoformat(sep=' ')})
    with Path(path).open('w',encoding='utf-8-sig',newline='') as file:
        cols=['pattern','length','fraud','legit','precision_in_sample','relative_frequency','example_client','first_time','last_time']
        writer=csv.DictWriter(file,fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def main(db, triples_csv,out,max_seeds=15,min_support=5,max_four_for_five=25):
    history=read_histories(db,48)
    with open(triples_csv,encoding='utf-8-sig',newline='') as f:
        triples=list(csv.DictReader(f))
    triples.sort(key=lambda r:(-int(r['fraud']),int(r['legit']),r['pattern']))
    seeds=[tuple(z['pattern'].split(' -> ')) for z in triples[:max_seeds]]
    span=timedelta(hours=24)
    fours,examples4=grow(history,seeds,4,span)
    out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    n4=write(out/'length4.csv',fours,examples4,history,min_support)
    next_seeds=[pattern for pattern,count in fours.most_common() if count>=min_support][:max_four_for_five]
    fives,examples5=grow(history,next_seeds,5,span)
    n5=write(out/'length5.csv',fives,examples5,history,min_support)
    summary={'seed_triples':len(seeds),'observed_four':len(fours),'selected_four':n4,
             'extended_four':len(next_seeds),'observed_five':len(fives),'selected_five':n5,
             'warning':'Prefix-growth subset only; not exhaustive over all 4/5-event sequences.'}
    (out/'long_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db',required=True)
    p.add_argument('--triples',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--max-seeds',type=int,default=15)
    p.add_argument('--min-positive-support',type=int,default=5)
    p.add_argument('--max-four-for-five',type=int,default=25)
    a=p.parse_args()
    main(a.db,a.triples,a.out,a.max_seeds,a.min_positive_support,a.max_four_for_five)
