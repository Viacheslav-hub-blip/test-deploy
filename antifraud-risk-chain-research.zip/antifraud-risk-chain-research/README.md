# Навык: антифрод-исследование рисковых цепочек

Переиспользуемый каталог ИИ-агента. Основная точка входа — `SKILL.md`, документы в `references/` открываются по необходимости. В комплект включены методика и демонстрационное восьмиблочное правило; **исходные клиентские события, SQLite-база и обученные модели не включены**. Для воспроизведения исследовательских метрик требуется исходный обезличенный набор с колонками, перечисленными в `references/01_data_and_time_contract.md`.

## Структура

```text
antifraud-risk-chain-skill/
├── SKILL.md
├── README.md
├── requirements.txt
├── references/
│   ├── 01_data_and_time_contract.md
│   ├── 02_sequence_mining.md
│   ├── 03_modeling_and_evaluation.md
│   ├── 04_interpretable_rule.md
│   ├── 05_sql_and_validation.md
│   ├── 06_quality_gate.md
│   └── 07_tools_and_reproducibility.md
├── scripts/
│   ├── xlsx_to_csv.py
│   ├── ingest_csv.py
│   ├── mine_sequences.py
│   ├── mine_long_sequences.py
│   ├── generate_candidates.py
│   ├── compile_selected_rule.py
│   ├── benchmark_models.py
│   ├── select_rule.py
│   ├── evaluate_rule.py
│   └── build_report.py
├── templates/
│   ├── report_outline.md
│   ├── candidate_flags.json
│   └── branch_descriptions.json
├── assets/
│   ├── reference_rule_sqlite.sql
│   ├── reference_validation_sqlite.sql
│   ├── reference_rule_banking.txt
│   ├── reference_rule_contributions.json
│   ├── reference_metrics.csv
│   └── reference_report.html
└── tests/
    ├── test_reference_rule.py
    └── test_compile_selected.py
```

## Быстрый старт на исходном Excel

Запустить из корня папки с навыком. Подготовить Python 3.11+, SQLite 3.25+; зависимости: `pip install -r requirements.txt` для полного набора (тесты SQL используют стандартную библиотеку).

```bash
python scripts/xlsx_to_csv.py \
  --xlsx '/path/to/sample_1000_clients_task1_basic_with_legitimate_test_clean (1).xlsx' \
  --csv '/path/to/events.csv' --last-row 37792 --columns 20

python scripts/ingest_csv.py --csv '/path/to/events.csv' --db '/path/to/events.sqlite'

python scripts/mine_sequences.py --db '/path/to/events.sqlite' \
  --out '/path/to/results/patterns' --window-hours 24 --history-hours 48

python scripts/mine_long_sequences.py --db '/path/to/events.sqlite' \
  --triples '/path/to/results/patterns/triples.csv' --out '/path/to/results/long' \
  --max-seeds 15

python scripts/evaluate_rule.py --db '/path/to/events.sqlite' \
  --rule assets/reference_rule_sqlite.sql --output '/path/to/results/evaluation' \
  --expect-reference

python scripts/benchmark_models.py --db '/path/to/events.sqlite' \
  --out '/path/to/results/ml' --folds 5 --inner 3

python scripts/generate_candidates.py --db '/path/to/events.sqlite' \
  --pairs '/path/to/results/patterns/pairs.csv' \
  --out '/path/to/results/candidates.json' --max-types 6 --max-pairs 6

python scripts/select_rule.py --db '/path/to/events.sqlite' \
  --candidates '/path/to/results/candidates.json' --out '/path/to/results/selection'

python scripts/compile_selected_rule.py \
  --selection '/path/to/results/selection/selection.json' \
  --candidates '/path/to/results/candidates.json' --out '/path/to/results/compiled'

# Для анализа НОВОГО выбранного правила, а не эталона:
python scripts/evaluate_rule.py --db '/path/to/events.sqlite' \
  --rule '/path/to/results/compiled/selected_rule.sql' \
  --view antifraud_selected_event_flags \
  --output '/path/to/results/new_rule_evaluation'

# Следующий отчёт использует эталонный набор условий. Для нового правила передать
# --rules, --sql, --descriptions и метрики нового оценочного прогона.
python scripts/build_report.py \
  --metrics '/path/to/results/evaluation/metrics.json' \
  --contributions '/path/to/results/evaluation/rule_contributions.csv' \
  --pairs '/path/to/results/patterns/pairs.csv' \
  --triples '/path/to/results/patterns/triples.csv' \
  --output '/path/to/results/final_report.html'

python -m unittest discover -s tests -v
```

Если готовая таблица `events` уже в SQLite, первые две команды не нужны. `--expect-reference` применять только к эталонному XLSX; для новых данных убрать. При неизвестной длине таблицы можно пропустить `--last-row`: конвертер прочитает все строки листа потоково. Конвертер использует стандартные средства Python для чтения ZIP/XML плоского Excel без изменения книги; для сложных формул/нескольких нестандартно пронумерованных листов предварительно проверьте исходные значения. Если колонки расположены иначе, предварительно согласовать отображение.

**Важно про `select_rule.py`:** файл `templates/candidate_flags.json` содержит лишь готовые восемь ветвей для демонстрации алгоритма объединения. `generate_candidates.py` создаёт расширяемый пул из наблюдаемых подтипов, сеток score/amount и частых пар, не выбирая пары по lift. Опциональные тройки прошли отбор по метке и не годятся для полноценной вложенной проверки без перегенерации внутри обучения. На новых данных расширяйте множество SQL-предикатов по результатам поиска цепочек и порогов; скрипт не претендует автоматически повторить полный исторический подбор сотен кандидатов. Повторная оценка по 5 фолдам с этим коротким пулом может отличаться от эталонной проверки перевыбора по широкому пулу (`62 TP / 87 FP`). В любом случае сценарий `select_rule.py` не заменяет независимый временной тест.

**Важно про модели:** `benchmark_models.py` демонстрирует собственную воспроизводимую матрицу as-of признаков и вложенную проверку, а не загрузку старых обученных весов. Метрики новых запусков могут не совпадать с референсным сравнением, где набор признаков шире. Нельзя объявлять старые численные результаты результатом этого нового скрипта без запуска.

**Важно про SQL:** `assets/reference_rule_sqlite.sql` прогнозирует, а `assets/reference_validation_sqlite.sql` оценивает метрики и использует `fraud_time` только офлайн. Рабочий SQL не фильтрует входные операции и не использует метки исхода. Для PostgreSQL/Spark адаптировать интервал/касты и повторить тесты.

**Новый SQL без ручной сборки:** `compile_selected_rule.py` превращает выбранные SQL-предикаты из `selection.json` и файла кандидатов в представление `antifraud_selected_event_flags`. Для оценки передать `--view antifraud_selected_event_flags` и его сгенерированный SQL. При новом правиле описания блоков в автоматически полученном `selected_rule_descriptions.json` являются только техническими заглушками; агент обязан заменить их предметной интерпретацией перед публикацией отчёта. Оценщик в этом режиме показывает протокол 48 часов с полными исходными флагами; историческое специальное обрезание G1 выполняется только у неизменённого эталонного правила.
