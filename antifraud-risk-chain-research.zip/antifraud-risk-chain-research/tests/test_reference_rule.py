"""Synthetic, non-sensitive tests for exact SQL rule semantics."""
import sqlite3
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from evaluate_rule import stats


class RuleSemantics(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.execute('''CREATE TABLE events (
            epk_id TEXT,event_time TEXT,event_type TEXT,sub_type TEXT,
            cards_dsl_model_risk_score TEXT,inrubles TEXT,fraud_time TEXT)''')
        self.rule = (ROOT / 'assets/reference_rule_sqlite.sql').read_text(encoding='utf-8')
        self.db.executescript(self.rule.split('-- Просмотр сработок на УРОВНЕ СОБЫТИЙ')[0])

    def tearDown(self):
        self.db.close()

    def event(self, client, time, subtype, score=None, amount=None, typ='OTHER', fraud=None):
        cur = self.db.execute('INSERT INTO events VALUES (?,?,?,?,?,?,?)',
                              (client, time, typ, subtype, score, amount, fraud))
        return cur.lastrowid

    def group(self, rid, number):
        names = ['g1_atm_cash_48h', 'g2_epos_pos_payment', 'g3_epos_score',
                 'g4_c2b_score', 'g5_score_amount', 'g6_rurpayjursb',
                 'g7_vk_without_otp', 'g8_account_epos']
        return self.db.execute(f'SELECT {names[number-1]} FROM antifraud_event_flags WHERE event_row_id=?',(rid,)).fetchone()[0]

    def test_g1_two_cash_inside_inclusive_window_and_duplicates(self):
        old = self.event('one','2026-09-01 00:00:00','ATM_CASH')
        now = self.event('one','2026-09-03 00:00:00','ATM_CASH')
        self.assertEqual(self.group(old,1),0)
        self.assertEqual(self.group(now,1),1)
        outside = self.event('two','2026-09-01 00:00:00','ATM_CASH')
        far = self.event('two','2026-09-03 00:00:01','ATM_CASH')
        self.assertEqual(self.group(far,1),0)
        first = self.event('three','2026-09-03 00:00:00','ATM_CASH')
        second = self.event('three','2026-09-03 00:00:00','ATM_CASH')
        self.assertEqual(self.group(first,1),1)
        self.assertEqual(self.group(second,1),1)
        self.assertNotEqual(first,second)

    def test_g2_nonneighbor_order_score_and_strict_time(self):
        self.event('a','2026-09-01 08:00:00','EPOS_PURCHASE')
        self.event('a','2026-09-01 08:05:00','UNRELATED')
        self.event('a','2026-09-01 09:00:00','POS_PURCHASE')
        miss=self.event('a','2026-09-01 09:30:00','ANY',score='399',typ='PAYMENT')
        hit=self.event('a','2026-09-01 09:40:00','ANY',score='400',typ='WITHDRAW')
        self.assertEqual(self.group(miss,2),0)
        self.assertEqual(self.group(hit,2),1)
        self.event('b','2026-09-01 08:00:00','EPOS_PURCHASE')
        self.event('b','2026-09-01 08:00:00','POS_PURCHASE')
        fail=self.event('b','2026-09-01 09:00:00','ANY',score='800',typ='PAYMENT')
        self.assertEqual(self.group(fail,2),0)

    def test_single_operation_thresholds_and_missing(self):
        candidates=[(3,'EPOS_PURCHASE','450',None),(4,'C2B_SUBSCRIBE','250',None),
                    (5,'OTHER','800','500'),(6,'RURPAYJURSB','450',None)]
        for i,(g,sub,score,amount) in enumerate(candidates):
            rid=self.event(str(i),'2026-09-02 10:00:00',sub,score,amount)
            self.assertEqual(self.group(rid,g),1)
            rid_missing=self.event('null'+str(i),'2026-09-02 10:00:00',sub,'',amount)
            self.assertEqual(self.group(rid_missing,g),0)
        noamount=self.event('amt','2026-09-02 10:00:00','OTHER','800','')
        self.assertEqual(self.group(noamount,5),0)

    def test_g7_and_g8_past_only(self):
        self.event('vk','2026-09-01 12:00:00','VK_CHECK')
        self.event('vk','2026-09-01 12:02:00','UNRELATED')
        self.event('vk','2026-09-01 13:00:00','WITHOUT_OTP')
        r=self.event('vk','2026-09-01 14:00:00','FIN',score='400',typ='PAYMENT')
        self.assertEqual(self.group(r,7),1)
        now=self.event('account','2026-09-01 13:00:00','EPOS_PURCHASE','300')
        self.event('account','2026-09-01 14:00:00','ACCOUNT')
        self.assertEqual(self.group(now,8),0)
        after=self.event('account','2026-09-01 15:00:00','EPOS_PURCHASE','300')
        self.assertEqual(self.group(after,8),1)

    def test_labels_do_not_affect_prediction(self):
        rid=self.event('a','2026-09-01 09:00:00','EPOS_PURCHASE','450','100')
        before=self.db.execute('SELECT antifraud_flag,triggered_groups FROM antifraud_event_flags WHERE event_row_id=?',(rid,)).fetchone()
        self.db.execute('UPDATE events SET fraud_time=? WHERE rowid=?',('2026-09-03 09:00:00',rid))
        after=self.db.execute('SELECT antifraud_flag,triggered_groups FROM antifraud_event_flags WHERE event_row_id=?',(rid,)).fetchone()
        self.assertEqual(before,after)

    def test_metrics_client_level(self):
        self.assertEqual(stats([(1,1),(1,0),(0,1),(0,0)])['TP'],1)
        self.assertEqual(stats([(1,1),(1,0),(0,1),(0,0)])['FP'],1)


if __name__=='__main__':
    unittest.main()
