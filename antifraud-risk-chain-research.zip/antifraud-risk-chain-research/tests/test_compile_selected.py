"""The generated SQL must execute and produce an outcome-free selected view."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'scripts'))
from compile_selected_rule import compile_rule


class CompiledRuleTests(unittest.TestCase):
    def test_compile_and_query(self):
        with tempfile.TemporaryDirectory() as temp:
            d = Path(temp)
            (d / 'selection.json').write_text(json.dumps({'selected': ['ePOS >=450']}))
            (d / 'candidates.json').write_text(json.dumps({'candidates': [
                {'name': 'ePOS >=450', 'expression': "e.sub_type='EPOS_PURCHASE' AND e.dsl_score>=450"}]}))
            sql = compile_rule(d / 'selection.json', d / 'candidates.json',
                               BASE / 'assets/reference_rule_sqlite.sql', d)
            self.assertNotIn('fraud_time', '\n'.join(
                line for line in sql.splitlines() if not line.lstrip().startswith('--')))
            db=sqlite3.connect(':memory:')
            db.execute('''CREATE TABLE events(epk_id TEXT,event_time TEXT,event_type TEXT,sub_type TEXT,
                         cards_dsl_model_risk_score TEXT,inrubles TEXT,fraud_time TEXT)''')
            db.execute("INSERT INTO events VALUES('a','2026-09-01 10:00:00','PAYMENT','EPOS_PURCHASE','450','700',NULL)")
            db.executescript(sql)
            self.assertEqual(db.execute('SELECT antifraud_flag FROM antifraud_selected_event_flags').fetchone()[0],1)
            self.assertEqual(db.execute('SELECT g1_selected FROM antifraud_selected_event_flags').fetchone()[0],1)
            db.close()

    def test_outcome_leakage_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp)
            (d/'selection.json').write_text(json.dumps({'selected':['bad']}))
            (d/'candidates.json').write_text(json.dumps({'candidates':[{'name':'bad','expression':'e.fraud_time IS NOT NULL'}]}))
            with self.assertRaises(ValueError):
                compile_rule(d/'selection.json',d/'candidates.json',
                             BASE/'assets/reference_rule_sqlite.sql',d)


if __name__=='__main__':
    unittest.main()
