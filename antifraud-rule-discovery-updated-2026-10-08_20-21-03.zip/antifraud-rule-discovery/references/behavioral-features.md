# Поведенческие и производные признаки

Читать при использовании, проверке или расчёте исторических и производных признаков. Эти фичи можно использовать в качестве примеров и отправной точки

Функции в примерах: `compute_burst_score`.

## Оглавление

- [Исторические признаки и сочетания источников](#исторические-признаки-и-сочетания-источников)
- [Шаблоны гипотез для комбинаций](#шаблоны-гипотез-для-комбинаций)
- [Простые производные признаки](#простые-производные-признаки)
- [Входы примеров расчёта](#входы-примеров-расчёта)
- [Временные окна до ref_time](#временные-окна-до-ref_time)
- [Взвешенные признаки (экспоненциальное затухание)](#взвешенные-признаки-экспоненциальное-затухание)
- [Burst score: максимальная концентрация в 1 час](#burst-score-максимальная-концентрация-в-1-час)
- [Events per hour: интенсивность активности](#events-per-hour-интенсивность-активности)
- [Night events: ночная активность](#night-events-ночная-активность)

## Исторические признаки и сочетания источников

Когда параметры целевой операции недоступны, исследуй поведенческие признаки из истории до момента решения. Если тебе доступны параметры самой операции у которой стоит 1, то ты можешь их использовать

Исследуй сочетания сырых транзакций и событий мониторинга, если оба источника доступны.
Для каждого признака фиксируй источник, окно, момент доступности и единицу расчёта.

**Примеры групп фичей**

| Семейство | Смысл |
|---|---|
| `cnt_X` | Количество событий типа X за доступную историю до решения |
| `rcnt_W_X` | Количество событий типа X в предшествующем окне W |
| `wcnt_X` | Сумма весов `EXP(-lambda * hours_before)` для событий типа X |
| `burst_score` | Максимальное число событий в скользящем окне внутри доступной истории |
| `events_per_hour` | Интенсивность событий на выбранном временном интервале |
| `night_events` | Количество событий в заданном ночном интервале |
| `ops_per_day` | Среднее количество операций в день за выбранный период |

Окна 1, 6, 24 и 72 часа и предыдущее окно 24–48 часов — примеры для исследования разных фаз активности.
λ=0.1 при измерении времени в часах — пример экспоненциального затухания, а не обязательное значение.
Ночной интервал 23:00–06:00 — пример; фиксируй часовую зону и границы.
Сравнивай эти признаки с обычными счётчиками и проверяй вклад сочетаний: превосходство не гарантировано.

**Ты можешь самостоятельно добавлять группы и периоды**

**Дополниетльно**
Иногда новые интересные фичи можно извлекать из комбинаций значений в колонках 

**Пример**
Иногда в данных встречается колонка sub_type и event_description 
В sub_type бывает значение FS_REQUEST - это очень общее название для большого набора значений конкретика которых содержится в event_description. Поэтому ты можешь создавать новые фичи для более гранулярного изучения путем обьединения значений нескольких колонок

## Шаблоны гипотез для комбинаций

Эти шаблоны задают направления поиска. X/Y — смысловые типы событий, N/M/K — подбираемые пороги.
Ни один шаблон сам по себе не доказывает мошенничество.

```text
wcnt_X >= N AND events_per_hour >= M AND risk_last_72h >= K
rcnt_1h_X >= N AND ops_per_day >= M AND rcnt_6h_Y >= K
cnt_X >= N AND risk_last_24h >= M
night_events >= N AND rcnt_6h_X >= M
burst_score >= N AND rcnt_24h_X >= M
```


---

## Простые производные признаки

Если смысл признаков позволяет, можно создавать простые интерпретируемые производные.

Примеры:

```text
transfer_count_1h / (transfer_count_24h / 24)
amount_sum_1h / (amount_sum_24h / 24)
login_count_30m / login_count_24h
current_value - historical_baseline
```

Каждая производная должна иметь какой то человеческий смысл (исходя из чего мы это сделали, что мы предполагаем)

При делении используй безопасный знаменатель.

Пример SQL:

```sql
transfer_count_1h
/
NULLIF(transfer_count_24h / 24.0, 0)
```

Добавляй производные признаки в общий каталог и оценивай тем же способом, что исходные признаки.

---

## Входы примеров расчёта

`events_parquet_glob`, `decision_times_parquet`, `event_subtype` и `risk_subtypes` задаются по текущим источникам и каталогу.
В примерах условные колонки: `client_id`, `event_time`, `ref_time`, `sub_type`.


```python
import polars as pl
from datetime import timedelta

# Исходные данные
events = pl.scan_parquet(events_parquet_glob)  # источник текущего исследования
ref_times = pl.scan_parquet(decision_times_parquet)  # (client_id, ref_time)

# Присоединяем ref_time к каждому событию клиента
events_with_ref = events.join(
    ref_times,
    on="client_id",
    how="inner"
).filter(
    pl.col("event_time") < pl.col("ref_time")  # только события до решения
).with_columns(
    (pl.col("ref_time") - pl.col("event_time")).dt.total_seconds() / 3600.0
    .alias("hours_before")
)

# cnt_X: общее количество событий типа X
cnt_X = events_with_ref.filter(
    pl.col("sub_type") == event_subtype
).group_by("client_id").agg(
    pl.len().alias("cnt_X")
)

# rcnt_1h_X: за последний 1 час
rcnt_1h_X = events_with_ref.filter(
    (pl.col("sub_type") == event_subtype) &
    (pl.col("hours_before") <= 1.0)
).group_by("client_id").agg(
    pl.len().alias("rcnt_1h_X")
)

# rcnt_6h_X, rcnt_24h_X — аналогично с другими порогами
```

## Взвешенные признаки (экспоненциальное затухание)

```python
import numpy as np

# wcnt_X = SUM(EXP(-0.1 * hours_before))
# λ = 0.1 означает, что событие 10 часов назад весит ~37%, 24 часа назад ~9%

wcnt_X = events_with_ref.filter(
    pl.col("sub_type") == event_subtype
).with_columns(
    np.exp(-0.1 * pl.col("hours_before")).alias("weight")
).group_by("client_id").agg(
    pl.col("weight").sum().alias("wcnt_X")
)

# w_total: сумма всех взвешенных рисковых событий
RISK_SUBTYPES = risk_subtypes  # список типов из текущего каталога

w_total = events_with_ref.filter(
    pl.col("sub_type").is_in(RISK_SUBTYPES)
).with_columns(
    np.exp(-0.1 * pl.col("hours_before")).alias("weight")
).group_by("client_id").agg(
    pl.col("weight").sum().alias("w_total")
)
```

λ=0.1 здесь является иллюстративным значением; его полезность проверяй на текущих данных.

## Burst score: максимальная концентрация в 1 час

```python
def compute_burst_score(events_with_ref, risk_subtypes):
    """Иллюстрирует расчёт максимального числа событий в часовом окне.

    Вход: events_with_ref — события с hours_before; risk_subtypes — типы рисковых событий.
    Выход: таблица с идентификатором клиента и burst_score.
    Ограничения: непроверенный шаблон; группировка только по клиенту и Python-перебор.
    """
    events_filtered = events_with_ref.filter(
        pl.col("sub_type").is_in(risk_subtypes)
    ).sort(["client_id", "hours_before"])
    
    # Для каждого клиента считаем скользящее окно
    burst = events_filtered.group_by("client_id").agg(
        pl.col("hours_before")
        .map_elements(
            lambda hours: max([
                np.sum((hours >= h) & (hours < h + 1.0))
                for h in hours
            ]) if len(hours) > 0 else 0,
            return_dtype=pl.Int32
        )
        .alias("burst_score")
    )
    
    return burst
```

**Оптимизация:** Для больших данных использовать оконные функции Polars вместо map_elements.

## Events per hour: интенсивность активности

```python
events_per_hour = events_with_ref.filter(
    pl.col("sub_type").is_in(RISK_SUBTYPES)
).group_by("client_id").agg(
    pl.len().alias("total_risk_events"),
    pl.col("hours_before").max().alias("max_hours_before")
).with_columns(
    (pl.col("total_risk_events") / 
     pl.when(pl.col("max_hours_before") > 0)
     .then(pl.col("max_hours_before"))
     .otherwise(1.0))
    .alias("events_per_hour")
)
```

## Night events: ночная активность

```python
night_events = events_with_ref.filter(
    pl.col("sub_type").is_in(RISK_SUBTYPES)
).with_columns(
    pl.col("event_time").dt.hour().alias("hour")
).filter(
    (pl.col("hour") >= 23) | (pl.col("hour") < 6)
).group_by("client_id").agg(
    pl.len().alias("night_events")
)
```
