# SQL, отчёт и артефакты

Читать перед переносом логики в SQL и формированием результата текущей задачи.

## Оглавление

- [Формирование SQL](#формирование-sql)
- [SQL для расчёта исторических признаков](#sql-для-расчёта-исторических-признаков)
- [Артефакты исследования](#артефакты-исследования)
- [Формат таблицы кандидатов](#формат-таблицы-кандидатов)
- [Формат итогового отчёта](#формат-итогового-отчёта)

## Формирование SQL

Финальный SQL должен:

- использовать реальные названия признаков;
- сохранять явные скобки между AND/OR-ветками;
- корректно обрабатывать NULL;
- использовать production-доступные признаки;
- использовать округлённые устойчивые пороги;
- сохранять точную логику проверенного кандидата.

Пример:

```sql
CASE
    WHEN (
        device_change_24h >= 1
        AND transfer_count_1h >= 2
        AND login_count_30m >= 4
        AND amount_sum_1h >= 80000
        AND new_recipient_count_24h >= 1
    )
    OR (
        minutes_since_device_change <= 900
        AND transfer_amount >= 150000
        AND recipient_age_hours <= 24
    )
    THEN 1
    ELSE 0
END AS antifraud_rule
```

---

## SQL для расчёта исторических признаков

Если текущая задача требует расчёта признаков из истории, SQL может включать моменты решения, фильтрацию предшествующих событий, агрегаты, всплески, признаки транзакций и объединение результатов.
Используй только необходимые части; количество CTE не фиксировано.
Если входные признаки уже рассчитаны, не добавляй расчёт из сырых источников без необходимости.

Оптимизации для больших данных применяй по доступному движку и плану исполнения:

- Фильтрация нужных типов событий до агрегации.
- Партиционирование по ключам соединения.
- Broadcast join для действительно небольшой таблицы моментов решения, если движок поддерживает его.
- Кэширование повторно используемых промежуточных результатов, если это оправдано.

**Незавершённый SQL-шаблон ниже не выполняется как готовый запрос.**
`decision_times_source`, `monitoring_events_source` и `transactions_source` — условные источники текущего исследования.
Многоточия обозначают недостающий список типов и признаки. Диалект SQL нужно определить для текущей системы.

Известные ограничения исходной вычислительной схемы сохранены:

- Группировка только по клиенту предполагает один момент решения на клиента.
- Inner join и начало объединения с агрегатов исключают строки без истории.
- Расчёт `w_total` ограничен 72 часами, а `burst_score` использует весь доступный `risk_events`.
- В `features` не рассчитаны все признаки, указанные в финальных условиях.
- Границы скользящего окна и синтаксис временных функций требуют сверки с Python и целевым SQL-движком.

Это пример организации расчётов, а не подтверждение эквивалентности Python и SQL.

Пороги 27, 2.3, 100, 50 и 28 в запросе иллюстративны; подбирай значения по текущим данным.

```sql
WITH ref_times AS (
    SELECT client_id, ref_time FROM decision_times_source
),
risk_events AS (
    SELECT 
        e.client_id,
        e.sub_type,
        e.event_time,
        r.ref_time,
        EXTRACT(EPOCH FROM (r.ref_time - e.event_time)) / 3600.0 AS hours_before
    FROM monitoring_events_source e
    JOIN ref_times r ON e.client_id = r.client_id
    WHERE e.event_time < r.ref_time
      AND e.sub_type IN (...)  -- нужные типы из текущего каталога
),
risk_aggregates AS (
    SELECT 
        client_id,
        COUNT(*) AS risk_last_72h,
        SUM(CASE WHEN hours_before <= 1.0 THEN 1 ELSE 0 END) AS risk_last_1h,
        SUM(CASE WHEN hours_before <= 6.0 THEN 1 ELSE 0 END) AS risk_last_6h,
        SUM(CASE WHEN hours_before <= 24.0 THEN 1 ELSE 0 END) AS risk_last_24h,
        SUM(EXP(-0.1 * hours_before)) AS w_total,
        MAX(EXTRACT(HOUR FROM event_time)) AS max_hour,
        SUM(CASE WHEN EXTRACT(HOUR FROM event_time) >= 23 
                 OR EXTRACT(HOUR FROM event_time) < 6 THEN 1 ELSE 0 END) AS night_events
    FROM risk_events
    WHERE hours_before <= 72.0
    GROUP BY client_id
),
burst_calc AS (
    -- Вычисление burst_score через оконные функции
    SELECT 
        client_id,
        event_time,
        COUNT(*) OVER (
            PARTITION BY client_id 
            ORDER BY event_time 
            RANGE BETWEEN INTERVAL '1 hour' PRECEDING AND CURRENT ROW
        ) AS events_in_window
    FROM risk_events
),
burst_scores AS (
    SELECT client_id, MAX(events_in_window) AS burst_score
    FROM burst_calc
    GROUP BY client_id
),
ops_features AS (
    SELECT 
        client_id,
        COUNT(*) AS total_ops,
        COUNT(DISTINCT channel) AS unique_channels,
        SUM(CASE WHEN EXTRACT(HOUR FROM event_time) >= 23 
                 OR EXTRACT(HOUR FROM event_time) < 6 THEN 1 ELSE 0 END) AS night_ops_count,
        -- ... другие признаки из сырых транзакций
    FROM transactions_source
    WHERE event_time < (SELECT ref_time FROM ref_times WHERE ref_times.client_id = transactions_source.client_id)
    GROUP BY client_id
),
features AS (
    SELECT 
        r.client_id,
        r.w_total,
        r.risk_last_1h,
        r.risk_last_6h,
        r.risk_last_24h,
        r.risk_last_72h,
        r.night_events,
        b.burst_score,
        o.total_ops,
        o.unique_channels,
        o.night_ops_count,
        -- ... признаки текущего кандидата
    FROM risk_aggregates r
    JOIN burst_scores b ON r.client_id = b.client_id
    JOIN ops_features o ON r.client_id = o.client_id
)
SELECT 
    client_id,
    CASE
        WHEN (wcnt_X >= 27 AND events_per_hour >= 2.3 AND risk_last_72h >= 100)
        OR (w_total >= 50 AND events_per_hour >= 2.3 AND cnt_Y >= 28)
        -- ... дополнительные ветки текущего кандидата
        THEN 1
        ELSE 0
    END AS antifraud_rule
FROM features
```

---

## Артефакты исследования

Сохраняй результаты этапов, чтобы исследование можно было продолжить без повторного пересчёта.

Рекомендуемая структура результатов нового исследования; это выходные файлы, а не ссылки на существующий запуск:

```text
00_data_profile.json
01_feature_catalog.parquet
02_excluded_features.json
03_atomic_conditions.parquet
04_search_config.json
05_beam_depth_01.parquet
05_beam_depth_02.parquet
...
06_candidate_rules.parquet
07_validation_results.parquet
08_test_results.parquet
09_ablation_results.parquet
10_stability_results.parquet
best_rule.sql
rule_report.md
```

В `04_search_config.json` сохрани:

```text
seed
input fingerprint
schema
label semantics
split boundaries
search sample sizes
quantiles
beam width
safety max depth
FPR buckets
prevalence grid
```

Если в текущей задаче рассчитываются признаки или требуется подробное описание веток, дополнительно сохраняй матрицы признаков по split, правило в JSON с точными и округлёнными порогами и описание веток по сценариям.
SQL с расчётом признаков и HTML-отчёт добавляй только если они нужны в текущей задаче. Число CTE и размер файлов не фиксируются.

---

## Формат таблицы кандидатов

Для каждого правила сохраняй минимум:

```text
rule_id
parent_rule_id
conditions
n_conditions
n_clauses
feature_names

TP_discovery
FP_discovery
TPR_discovery
FPR_discovery
ConservativeSeparation_discovery

TP_validation
FP_validation
TPR_validation
FPR_validation
ConservativeSeparation_validation

min_TPR_over_time
max_FPR_over_time
threshold_stability

sql
```

Для финальных правил добавь Test-метрики.

---

## Формат итогового отчёта

Создай `rule_report.md`.

### Данные

```text
rows:
features:
fraud rows:
good rows:
observed fraud share:
time period:
unit of analysis:
decision point:
```

### Использованные и исключённые признаки

Кратко опиши группы признаков.

Для исключённых:

```text
feature | reason
```

### Метод поиска

Укажи:

```text
разделение Discovery/Validation/Test;
размер search sample;
способ генерации порогов;
размер пула атомарных условий;
beam width;
максимальную исследованную глубину;
Pareto-критерии;
способ проверки устойчивости.
```

### Рекомендуемое правило

Покажи человекочитаемую логику.

### SQL

Покажи полный SQL.

### Основные метрики

Таблица:

```text
Split | TP | FP | TPR | FPR | Separation | ConservativeSeparation
```

### Устойчивость к доле Fraud

Таблица:

```text
fraud_rate
precision_expected
alert_rate
fraud_hits_per_1m
false_hits_per_1m
```

Минимум для `0.006 ... 0.5`.

### Стабильность по времени

Покажи TPR/FPR по временным периодам.

### Стабильность по сегментам

Покажи важные сегменты и возможные слабые места.

### Ablation

Таблица:

```text
condition
TPR_full
FPR_full
TPR_without
FPR_without
interpretation
```

### Альтернативные правила

Покажи несколько Pareto-best вариантов, если они представляют разные компромиссы TPR/FPR.

### Вывод

Сформулируй:

```text
что именно отличает Fraud от Good;
почему выбранное правило устойчиво;
какой ожидается поток срабатываний;
при каких долях Fraud правило остаётся практически применимым;
какие ограничения обнаружены.
```

В раздел устойчивости включи сценарий отключения веток при недоступности признака и потерю покрытия.
Названия файлов и фактические результаты конкретного исследования храни в его отчёте, а переносимые инструкции — в skill.
