# Метрики и единая оценка

Читать до оценки условий или кандидатов и перед расчётом ожидаемой нагрузки.

Функции в примерах: `wilson_interval`, `metrics_at_prevalence`, `evaluate_counts`.

## Оглавление

- [Основная цель поиска](#основная-цель-поиска)
- [Устойчивость к разной доле Fraud](#устойчивость-к-разной-доле-fraud)
- [Оцени каждое атомарное условие](#оцени-каждое-атомарное-условие)
- [Проверка при разных долях Fraud](#проверка-при-разных-долях-fraud)
- [Итоговая функция оценки правила](#итоговая-функция-оценки-правила)

## Основная цель поиска

Ищи признаки и их комбинации, для которых вероятность выполнения условия среди Fraud заметно и устойчиво выше вероятности выполнения того же условия среди Good.

Основные показатели поиска:

```text
TPR = TP / (TP + FN)
FPR = FP / (FP + TN)
Separation = TPR / FPR
```

Где:

- `TPR` — доля Fraud, которую покрывает правило;
- `FPR` — доля Good, которая попадает под правило;
- `Separation` — во сколько раз правило чаще встречается внутри Fraud, чем внутри Good.

Пример:

```text
TPR = 0.30
FPR = 0.005
Separation = 60
```

Такое правило выполняется примерно у 30% Fraud и у 0.5% Good.

---

## Устойчивость к разной доле Fraud

Доля Fraud во входной выборке может сильно меняться, например:

```text
0.006
0.01
0.05
0.10
0.50
```

Поэтому основной поиск веди по метрикам, рассчитанным отдельно внутри Fraud и Good:

```text
TPR
FPR
TPR / FPR
recall @ specificity 99%
```
Эти метрики сравнивают срабатывания внутри классов. Пересчёт для другой доли Fraud предполагает сохранение TPR/FPR; изменение состава классов требует отдельной проверки.

Precision рассчитывай отдельно для заданной доли Fraud.

Для доли Fraud `p`:

```text
Precision(p) =
    p * TPR
    /
    (p * TPR + (1 - p) * FPR)
```

Ожидаемая доля срабатываний:

```text
AlertRate(p) =
    p * TPR + (1 - p) * FPR
```

Количество срабатываний на миллион событий:

```text
FraudHitsPer1M(p) = 1_000_000 * p * TPR
FalseHitsPer1M(p) = 1_000_000 * (1 - p) * FPR
```

По умолчанию проверяй правило как минимум для:

```python
PREVALENCE_GRID = [
    0.006,
    0.01, 
    0.10,
    0.50,
]
```

Пример:

```text
TPR = 0.30
FPR = 0.005

Fraud rate = 0.006 -> Precision ≈ 26.6%
Fraud rate = 0.010 -> Precision ≈ 37.7%
Fraud rate = 0.050 -> Precision ≈ 75.9%
Fraud rate = 0.100 -> Precision ≈ 87.0%
Fraud rate = 0.500 -> Precision ≈ 98.4%
```

При сравнении правил основной акцент делай на TPR и FPR. Precision используй для оценки конкретного сценария.

---

## Оцени каждое атомарное условие

Для каждого условия вычисли:

```text
TP
FP
TPR
FPR
Separation
Fraud support
Good support
```

Также рассчитай доверительные интервалы для TPR и FPR.

Используй Wilson interval.

```python
import math


def wilson_interval(k: int, n: int, z: float = 1.96):
    """Возвращает интервал Уилсона для доли успехов.

    Вход: k — число успехов, n — число наблюдений, z — квантиль нормального распределения.
    Выход: кортеж нижней и верхней границ; при n=0 — (0.0, 1.0).
    """
    if n == 0:
        return 0.0, 1.0

    p = k / n
    z2 = z * z
    denom = 1.0 + z2 / n

    center = (
        p + z2 / (2.0 * n)
    ) / denom

    half = (
        z
        * math.sqrt(
            p * (1.0 - p) / n
            + z2 / (4.0 * n * n)
        )
        / denom
    )

    return (
        max(0.0, center - half),
        min(1.0, center + half),
    )
```

Для консервативной оценки используй:

```text
ConservativeSeparation = TPR_low / FPR_high
```

Если FPR равен нулю на конечной выборке, используй верхнюю доверительную границу `FPR_high`.

Пример функции Уилсона предполагает корректные счётчики `0 <= k <= n` и положительный `z`; проверки входов не реализованы.

---

## Проверка при разных долях Fraud

После фиксации TPR и FPR на Validation/Test рассчитай production-метрики для всей сетки долей Fraud.

Используй функцию:

```python
def metrics_at_prevalence(tpr, fpr, p):
    """Пересчитывает precision и нагрузку при заданной доле Fraud.

    Вход: tpr и fpr — доли срабатываний внутри классов, p — доля Fraud.
    Выход: словарь precision, доли срабатываний и числа попаданий на миллион событий.
    """
    alert_rate = p * tpr + (1.0 - p) * fpr

    precision = (
        p * tpr / alert_rate
        if alert_rate > 0
        else 0.0
    )

    return {
        "fraud_prevalence": p,
        "precision": precision,
        "alert_rate": alert_rate,
        "fraud_hits_per_1m": 1_000_000 * p * tpr,
        "false_hits_per_1m": 1_000_000 * (1.0 - p) * fpr,
    }
```

И сформируй таблицу:

```text
fraud_rate
precision_expected
alert_rate
fraud_hits_per_1m
false_hits_per_1m
```

---

## Итоговая функция оценки правила

Используй единый evaluator для всех кандидатов.

```python
import math


def evaluate_counts(tp, fp, n_fraud, n_good):
    """Вычисляет метрики правила и доверительные границы по счётчикам.

    Вход: tp, fp — срабатывания по классам; n_fraud, n_good — размеры классов.
    Выход: словарь TP/FP/FN/TN, TPR/FPR, specificity, Separation и границ Уилсона.
    """
    fn = n_fraud - tp
    tn = n_good - fp

    tpr = tp / n_fraud if n_fraud else 0.0
    fpr = fp / n_good if n_good else 0.0
    specificity = 1.0 - fpr

    tpr_low, tpr_high = wilson_interval(tp, n_fraud)
    fpr_low, fpr_high = wilson_interval(fp, n_good)

    separation = (
        tpr / fpr
        if fpr > 0
        else math.inf
    )

    conservative_separation = (
        tpr_low / fpr_high
        if fpr_high > 0
        else math.inf
    )

    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "tpr": tpr,
        "fpr": fpr,
        "specificity": specificity,
        "separation": separation,
        "tpr_low": tpr_low,
        "tpr_high": tpr_high,
        "fpr_low": fpr_low,
        "fpr_high": fpr_high,
        "conservative_separation": conservative_separation,
    }
```

Все генераторы кандидатов должны передавать правила в этот evaluator.

Сохранённый evaluator не проверяет входные счётчики. При пустом классе он возвращает нулевую долю, а Separation при FPR=0 — бесконечность; это вычислительная конвенция примера, а не доказательство качества.
Доверительные интервалы в этих шаблонах не учитывают зависимость повторных событий клиента. Не делай вывод об устойчивости только по ним.
